import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import 'app_state.dart';
import 'notify.dart';
import 'screens/call_screen.dart';

/// Дополнительные ICE-серверы. Для звонков между разными сетями (мобильный интернет,
/// строгие NAT) нужен TURN-сервер, например coturn. Пример:
///   {'urls': 'turn:ВАШ_СЕРВЕР:3478', 'username': 'user', 'credential': 'pass'},
const List<Map<String, dynamic>> kExtraIceServers = [];

enum CallPhase { idle, calling, incoming, connecting, active, ended }

/// Голосовые и видеозвонки (WebRTC). Сигналы идут через WebSocket-сервер.
class CallService extends ChangeNotifier {
  CallService._();
  static final CallService I = CallService._();

  GlobalKey<NavigatorState>? _navKey;
  final RTCVideoRenderer localRenderer = RTCVideoRenderer();
  final RTCVideoRenderer remoteRenderer = RTCVideoRenderer();

  CallPhase phase = CallPhase.idle;
  String peer = '';
  String peerName = '';
  bool video = false;
  bool incoming = false;
  bool muted = false;
  bool speakerOn = false;
  bool cameraOff = false;
  int seconds = 0;
  String? endReason;

  RTCPeerConnection? _pc;
  MediaStream? _local;
  MediaStream? _remote;
  Map<String, dynamic>? _pendingOffer;
  final List<Map<String, dynamic>> _pendingIce = [];
  bool _remoteSet = false;
  DateTime? _connectedAt;
  Timer? _ticker;
  Timer? _timeout;
  Timer? _ring;
  bool _finishing = false;

  bool get hasRemoteVideo => _remote?.getVideoTracks().isNotEmpty ?? false;
  bool get hasLocalVideo => _local?.getVideoTracks().isNotEmpty ?? false;

  Future<void> init(GlobalKey<NavigatorState> key) async {
    _navKey = key;
    await localRenderer.initialize();
    await remoteRenderer.initialize();
    AppState.I.signals.listen(_onSignal);
  }

  // ---------- публичные действия ----------
  Future<void> start(String to, String name, {required bool video}) async {
    if (AppState.I.demo) {
      AppState.I.pushError('В демо-режиме звонки недоступны: нужен сервер');
      return;
    }
    if (phase != CallPhase.idle) return;
    if (!AppState.I.connected) {
      AppState.I.pushError('Нет соединения с сервером');
      return;
    }
    _reset();
    peer = to;
    peerName = name;
    this.video = video;
    incoming = false;
    phase = CallPhase.calling;
    notifyListeners();
    _openScreen();

    if (!await _prepareLocal()) {
      await _finish('Нет доступа к микрофону или камере', notifyPeer: false);
      return;
    }
    try {
      await _createPc();
      final offer = await _pc!.createOffer();
      // сначала отправляем offer, потом включаем сбор ICE — так кандидаты не обгонят offer
      AppState.I.sendSignal({
        'type': 'call_offer',
        'to': to,
        'sdp': offer.sdp,
        'sdpType': offer.type,
        'video': video,
      });
      await _pc!.setLocalDescription(offer);
    } catch (_) {
      await _finish('Не удалось начать звонок');
      return;
    }
    _timeout = Timer(const Duration(seconds: 45), () {
      if (phase == CallPhase.calling) _finish('Нет ответа');
    });
  }

  Future<void> accept() async {
    if (phase != CallPhase.incoming || _pendingOffer == null) return;
    _stopRing();
    _timeout?.cancel();
    phase = CallPhase.connecting;
    notifyListeners();

    if (!await _prepareLocal()) {
      AppState.I.sendSignal({'type': 'call_reject', 'to': peer, 'reason': 'media'});
      await _finish('Нет доступа к микрофону или камере', notifyPeer: false);
      return;
    }
    try {
      await _createPc();
      final offer = _pendingOffer!;
      await _pc!.setRemoteDescription(RTCSessionDescription(
        offer['sdp'] as String,
        (offer['sdpType'] as String?) ?? 'offer',
      ));
      _remoteSet = true;
      await _flushIce();
      final answer = await _pc!.createAnswer();
      AppState.I.sendSignal({
        'type': 'call_answer',
        'to': peer,
        'sdp': answer.sdp,
        'sdpType': answer.type,
      });
      await _pc!.setLocalDescription(answer);
    } catch (_) {
      await _finish('Не удалось принять звонок');
    }
  }

  Future<void> reject() async {
    if (phase != CallPhase.incoming) return;
    AppState.I.sendSignal({'type': 'call_reject', 'to': peer, 'reason': 'declined'});
    await _finish('Вызов отклонён', notifyPeer: false);
  }

  Future<void> hangup() async {
    await _finish(phase == CallPhase.calling ? 'Вызов отменён' : 'Звонок завершён');
  }

  void toggleMute() {
    muted = !muted;
    for (final t in _local?.getAudioTracks() ?? <MediaStreamTrack>[]) {
      t.enabled = !muted;
    }
    notifyListeners();
  }

  void toggleSpeaker() {
    speakerOn = !speakerOn;
    Helper.setSpeakerphoneOn(speakerOn);
    notifyListeners();
  }

  void toggleCamera() {
    cameraOff = !cameraOff;
    for (final t in _local?.getVideoTracks() ?? <MediaStreamTrack>[]) {
      t.enabled = !cameraOff;
    }
    notifyListeners();
  }

  Future<void> switchCamera() async {
    final tracks = _local?.getVideoTracks() ?? <MediaStreamTrack>[];
    if (tracks.isNotEmpty) {
      try {
        await Helper.switchCamera(tracks.first);
      } catch (_) {}
    }
  }

  // ---------- сигналы от сервера ----------
  void _onSignal(Map<String, dynamic> m) {
    final type = m['type'] as String?;
    final from = (m['from'] as String?) ?? '';

    switch (type) {
      case 'call_offer':
        if (phase != CallPhase.idle) {
          AppState.I.sendSignal({'type': 'call_reject', 'to': from, 'reason': 'busy'});
          return;
        }
        _reset();
        peer = from;
        peerName = (m['fromName'] as String?) ?? from;
        video = m['video'] == true;
        incoming = true;
        _pendingOffer = m;
        phase = CallPhase.incoming;
        notifyListeners();
        _openScreen();
        _startRing();
        Notify.I.showIncomingCall(peerName, video);
        _timeout = Timer(const Duration(seconds: 50), () {
          if (phase == CallPhase.incoming) _finish('Пропущенный вызов', notifyPeer: false);
        });
        break;

      case 'call_answer':
        if (phase != CallPhase.calling || from != peer) return;
        _handleAnswer(m);
        break;

      case 'call_ice':
        if (from != peer || phase == CallPhase.idle || phase == CallPhase.ended) return;
        if (_pc != null && _remoteSet) {
          _addIce(m);
        } else {
          _pendingIce.add(m);
        }
        break;

      case 'call_reject':
        if (phase == CallPhase.calling && from == peer) {
          _finish(
            m['reason'] == 'busy' ? 'Абонент занят' : 'Вызов отклонён',
            notifyPeer: false,
          );
        }
        break;

      case 'call_end':
        if (from == peer && phase != CallPhase.idle && phase != CallPhase.ended) {
          _finish(
            phase == CallPhase.incoming ? 'Пропущенный вызов' : 'Собеседник завершил звонок',
            notifyPeer: false,
          );
        }
        break;

      case 'call_unavailable':
        if (phase == CallPhase.calling && from == peer) {
          _finish('Абонент не в сети', notifyPeer: false);
        }
        break;
    }
  }

  Future<void> _handleAnswer(Map<String, dynamic> m) async {
    try {
      await _pc!.setRemoteDescription(RTCSessionDescription(
        m['sdp'] as String,
        (m['sdpType'] as String?) ?? 'answer',
      ));
      _remoteSet = true;
      _timeout?.cancel();
      phase = CallPhase.connecting;
      notifyListeners();
      await _flushIce();
    } catch (_) {
      await _finish('Ошибка соединения');
    }
  }

  // ---------- WebRTC ----------
  Future<bool> _prepareLocal() async {
    try {
      _local = await navigator.mediaDevices.getUserMedia({
        'audio': true,
        'video': video
            ? {
                'facingMode': 'user',
                'width': {'ideal': 640},
                'height': {'ideal': 480},
              }
            : false,
      });
      localRenderer.srcObject = _local;
      speakerOn = video;
      try {
        await Helper.setSpeakerphoneOn(speakerOn);
      } catch (_) {}
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> _createPc() async {
    final config = <String, dynamic>{
      'iceServers': [
        {
          'urls': [
            'stun:stun.l.google.com:19302',
            'stun:stun1.l.google.com:19302',
          ],
        },
        ...kExtraIceServers,
      ],
      'sdpSemantics': 'unified-plan',
    };
    final pc = await createPeerConnection(config);
    _pc = pc;

    for (final t in _local!.getTracks()) {
      await pc.addTrack(t, _local!);
    }

    pc.onIceCandidate = (RTCIceCandidate c) {
      if (c.candidate == null || peer.isEmpty) return;
      AppState.I.sendSignal({
        'type': 'call_ice',
        'to': peer,
        'candidate': c.candidate,
        'sdpMid': c.sdpMid,
        'sdpMLineIndex': c.sdpMLineIndex,
      });
    };

    pc.onTrack = (RTCTrackEvent e) {
      if (e.streams.isNotEmpty) {
        _remote = e.streams[0];
        remoteRenderer.srcObject = _remote;
        notifyListeners();
      }
    };

    pc.onConnectionState = (RTCPeerConnectionState s) {
      if (s == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
        _onConnected();
      } else if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed) {
        _finish(_connectedAt == null
            ? 'Не удалось установить соединение (возможно, нужен TURN-сервер)'
            : 'Соединение потеряно');
      }
    };
  }

  Future<void> _flushIce() async {
    final list = List<Map<String, dynamic>>.from(_pendingIce);
    _pendingIce.clear();
    for (final m in list) {
      await _addIce(m);
    }
  }

  Future<void> _addIce(Map<String, dynamic> m) async {
    try {
      await _pc?.addCandidate(RTCIceCandidate(
        m['candidate'] as String?,
        m['sdpMid'] as String?,
        (m['sdpMLineIndex'] as num?)?.toInt(),
      ));
    } catch (_) {}
  }

  void _onConnected() {
    if (_connectedAt != null || phase == CallPhase.ended || phase == CallPhase.idle) return;
    _connectedAt = DateTime.now();
    phase = CallPhase.active;
    _timeout?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_connectedAt != null) {
        seconds = DateTime.now().difference(_connectedAt!).inSeconds;
        notifyListeners();
      }
    });
    notifyListeners();
  }

  // ---------- завершение ----------
  Future<void> _finish(String reason, {bool notifyPeer = true}) async {
    if (_finishing || phase == CallPhase.idle || phase == CallPhase.ended) return;
    _finishing = true;

    if (notifyPeer && peer.isNotEmpty) {
      AppState.I.sendSignal({'type': 'call_end', 'to': peer});
    }
    _timeout?.cancel();
    _ticker?.cancel();
    _stopRing();

    final dur = _connectedAt == null ? 0 : DateTime.now().difference(_connectedAt!).inSeconds;
    AppState.I.addCall(CallRecord(
      peer: peer,
      peerName: peerName,
      video: video,
      incoming: incoming,
      answered: _connectedAt != null,
      ts: DateTime.now().millisecondsSinceEpoch,
      durationSec: dur,
    ));

    phase = CallPhase.ended;
    endReason = reason;
    notifyListeners();

    await _disposeMedia();

    Future.delayed(const Duration(milliseconds: 1100), () {
      _navKey?.currentState?.popUntil((r) => r.settings.name != '/call');
      Future.delayed(const Duration(milliseconds: 450), () {
        phase = CallPhase.idle;
        _finishing = false;
        notifyListeners();
      });
    });
  }

  Future<void> _disposeMedia() async {
    try {
      for (final t in _local?.getTracks() ?? <MediaStreamTrack>[]) {
        await t.stop();
      }
      await _local?.dispose();
    } catch (_) {}
    try {
      await _pc?.close();
      await _pc?.dispose();
    } catch (_) {}
    localRenderer.srcObject = null;
    remoteRenderer.srcObject = null;
    _pc = null;
    _local = null;
    _remote = null;
  }

  void _reset() {
    _pendingOffer = null;
    _pendingIce.clear();
    _remoteSet = false;
    _connectedAt = null;
    muted = false;
    speakerOn = false;
    cameraOff = false;
    seconds = 0;
    endReason = null;
    _finishing = false;
  }

  // ---------- рингтон ----------
  void _startRing() {
    void beat() {
      HapticFeedback.heavyImpact();
      SystemSound.play(SystemSoundType.alert);
    }

    beat();
    _ring = Timer.periodic(const Duration(milliseconds: 1800), (_) => beat());
  }

  void _stopRing() {
    _ring?.cancel();
    _ring = null;
    Notify.I.cancelCall();
  }

  void _openScreen() {
    _navKey?.currentState?.push(
      PageRouteBuilder<void>(
        settings: const RouteSettings(name: '/call'),
        transitionDuration: const Duration(milliseconds: 380),
        reverseTransitionDuration: const Duration(milliseconds: 300),
        pageBuilder: (_, __, ___) => const CallScreen(),
        transitionsBuilder: (_, anim, __, child) {
          final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
          return FadeTransition(
            opacity: curved,
            child: SlideTransition(
              position: Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
                  .animate(curved),
              child: child,
            ),
          );
        },
      ),
    );
  }
}
