import 'package:flutter/material.dart';

import '../app_state.dart';
import '../call_service.dart';
import '../theme.dart';
import '../utils.dart';

class CallsTab extends StatelessWidget {
  const CallsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.I,
      builder: (context, _) {
        final calls = AppState.I.calls;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 14, 20, 8),
              child: Text('Звонки', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
            ),
            Expanded(
              child: calls.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 40),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.call_outlined, size: 52, color: NebulaColors.accent2),
                            SizedBox(height: 14),
                            Text(
                              'Здесь появится история звонков.\nПозвонить можно из любого чата.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: NebulaColors.textDim, height: 1.4),
                            ),
                          ],
                        ),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.only(bottom: 24),
                      itemCount: calls.length,
                      itemBuilder: (context, i) => _CallTile(record: calls[i]),
                    ),
            ),
          ],
        );
      },
    );
  }
}

class _CallTile extends StatelessWidget {
  final CallRecord record;
  const _CallTile({required this.record});

  @override
  Widget build(BuildContext context) {
    final missed = record.incoming && !record.answered;
    final color = missed ? NebulaColors.danger : NebulaColors.textDim;
    final dir = record.incoming ? (missed ? 'Пропущенный' : 'Входящий') : 'Исходящий';
    final kind = record.video ? 'видео' : 'голос';
    final dur = record.answered ? ' · ${formatDuration(record.durationSec)}' : '';

    return InkWell(
      onTap: () => CallService.I.start(record.peer, record.peerName, video: record.video),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        child: Row(
          children: [
            NebulaAvatar(name: record.peerName, user: record.peer, size: 50),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    record.peerName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: missed ? NebulaColors.danger : NebulaColors.text,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(
                        record.incoming ? Icons.call_received : Icons.call_made,
                        size: 14,
                        color: color,
                      ),
                      const SizedBox(width: 4),
                      Flexible(
                        child: Text(
                          '$dir · $kind$dur · ${formatClock(record.ts)}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: color, fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Icon(
              record.video ? Icons.videocam_outlined : Icons.call_outlined,
              color: NebulaColors.accent2,
            ),
          ],
        ),
      ),
    );
  }
}
