import 'package:flutter/material.dart';

import '../app_state.dart';
import '../call_service.dart';
import '../theme.dart';
import '../utils.dart';

class ChatScreen extends StatefulWidget {
  final String peer; // логин собеседника
  final String peerName;
  const ChatScreen({super.key, required this.peer, required this.peerName});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _ctrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    AppState.I.loadHistory(widget.peer);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _send() {
    final t = _ctrl.text.trim();
    if (t.isEmpty) return;
    AppState.I.sendMessage(widget.peer, t);
    _ctrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    return SpaceBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          titleSpacing: 0,
          title: Row(
            children: [
              NebulaAvatar(name: widget.peerName, user: widget.peer, size: 38),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    NickText(
                      user: widget.peer,
                      name: widget.peerName,
                      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                    ),
                    Text(
                      '@${widget.peer}',
                      style: const TextStyle(fontSize: 12, color: NebulaColors.textDim),
                    ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            IconButton(
              tooltip: 'Голосовой звонок',
              icon: const Icon(Icons.call_outlined),
              onPressed: () =>
                  CallService.I.start(widget.peer, widget.peerName, video: false),
            ),
            IconButton(
              tooltip: 'Видеозвонок',
              icon: const Icon(Icons.videocam_outlined),
              onPressed: () =>
                  CallService.I.start(widget.peer, widget.peerName, video: true),
            ),
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: AnimatedBuilder(
                animation: AppState.I,
                builder: (context, _) {
                  final msgs = AppState.I.messages[widget.peer] ?? const <ChatMessage>[];
                  if (msgs.isEmpty) {
                    return const Center(
                      child: Text(
                        'Напишите первое сообщение',
                        style: TextStyle(color: NebulaColors.textDim),
                      ),
                    );
                  }
                  return ListView.builder(
                    reverse: true,
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                    itemCount: msgs.length,
                    itemBuilder: (context, i) {
                      final m = msgs[msgs.length - 1 - i];
                      return _Bubble(
                        key: ValueKey(m.id),
                        msg: m,
                        mine: m.from == AppState.I.username,
                        animate: AppState.I.freshIds.contains(m.id),
                      );
                    },
                  );
                },
              ),
            ),
            _InputBar(controller: _ctrl, onSend: _send),
          ],
        ),
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  final ChatMessage msg;
  final bool mine;
  final bool animate;
  const _Bubble({super.key, required this.msg, required this.mine, required this.animate});

  @override
  Widget build(BuildContext context) {
    final maxW = MediaQuery.of(context).size.width * 0.78;
    final bubble = Container(
      constraints: BoxConstraints(maxWidth: maxW),
      padding: const EdgeInsets.fromLTRB(14, 9, 12, 7),
      decoration: BoxDecoration(
        gradient: mine ? NebulaColors.gradient : null,
        color: mine ? null : NebulaColors.surface,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(20),
          topRight: const Radius.circular(20),
          bottomLeft: Radius.circular(mine ? 20 : 6),
          bottomRight: Radius.circular(mine ? 6 : 20),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Flexible(
            child: Text(msg.text, style: const TextStyle(fontSize: 15.5, height: 1.3)),
          ),
          const SizedBox(width: 10),
          Text(
            formatClock(msg.ts),
            style: TextStyle(
              fontSize: 11,
              color: Colors.white.withValues(alpha: mine ? 0.8 : 0.5),
            ),
          ),
        ],
      ),
    );

    final row = Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Align(
        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
        child: bubble,
      ),
    );

    if (!animate) return row;

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 320),
      curve: Curves.easeOutCubic,
      builder: (context, v, child) => Opacity(
        opacity: v.clamp(0.0, 1.0),
        child: Transform.translate(
          offset: Offset(mine ? (1 - v) * 28 : (1 - v) * -28, (1 - v) * 10),
          child: Transform.scale(
            scale: 0.94 + 0.06 * v,
            alignment: mine ? Alignment.bottomRight : Alignment.bottomLeft,
            child: child,
          ),
        ),
      ),
      child: row,
    );
  }
}

class _InputBar extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onSend;
  const _InputBar({required this.controller, required this.onSend});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: NebulaColors.bgDeep.withValues(alpha: 0.85),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: TextField(
                  controller: controller,
                  minLines: 1,
                  maxLines: 5,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: const InputDecoration(hintText: 'Сообщение'),
                ),
              ),
              const SizedBox(width: 8),
              ValueListenableBuilder<TextEditingValue>(
                valueListenable: controller,
                builder: (context, value, _) {
                  final has = value.text.trim().isNotEmpty;
                  return AnimatedScale(
                    scale: has ? 1 : 0.85,
                    duration: const Duration(milliseconds: 180),
                    curve: Curves.easeOutBack,
                    child: AnimatedOpacity(
                      opacity: has ? 1 : 0.5,
                      duration: const Duration(milliseconds: 180),
                      child: GestureDetector(
                        onTap: has ? onSend : null,
                        child: Container(
                          width: 48,
                          height: 48,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: NebulaColors.gradient,
                          ),
                          child: const Icon(Icons.send_rounded, color: Colors.white, size: 22),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
