import 'package:flutter/material.dart';

import '../app_state.dart';
import '../intro/intro_screen.dart';
import '../theme.dart';
import 'chat_screen.dart';

/// Премиум: описание, выбор заставки при входе.
class PremiumScreen extends StatelessWidget {
  const PremiumScreen({super.key});

  void _preview(BuildContext context, String style) {
    Navigator.of(context).push(
      PageRouteBuilder<void>(
        opaque: true,
        transitionDuration: const Duration(milliseconds: 300),
        pageBuilder: (ctx, _, __) =>
            IntroScreen(style: style, onDone: () => Navigator.of(ctx).maybePop()),
        transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SpaceBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: const Text('Nebula Премиум'),
        ),
        body: AnimatedBuilder(
          animation: AppState.I,
          builder: (context, _) {
            final s = AppState.I;
            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
              children: [
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    gradient: NebulaColors.gradient,
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(children: [
                        const Icon(Icons.workspace_premium, color: Colors.white),
                        const SizedBox(width: 8),
                        Text(
                          s.premium ? 'Премиум включён' : 'Премиум · 399 ₽',
                          style: const TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w800, color: Colors.white),
                        ),
                      ]),
                      const SizedBox(height: 10),
                      Text(
                        s.premium
                            ? 'Спасибо! Ниже можно выбрать заставку при входе.'
                            : 'Оплата в приложении появится позже. Сейчас премиум выдаёт администратор.',
                        style: const TextStyle(color: Colors.white, height: 1.35),
                      ),
                    ],
                  ),
                ),
                if (!s.premium) ...[
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: NebulaColors.surface,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Как оплатить',
                          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      const SizedBox(height: 8),
                      Text(
                        'Напиши администратору @$kAdminContact: он пришлёт реквизиты. '
                        'Переведи 399 ₽, и после проверки он включит тебе премиум.',
                        style: const TextStyle(color: NebulaColors.textDim, height: 1.35),
                      ),
                      const SizedBox(height: 12),
                      FilledButton.icon(
                        onPressed: s.username == kAdminContact
                            ? null
                            : () => Navigator.of(context).push(MaterialPageRoute<void>(
                                  builder: (_) =>
                                      const ChatScreen(peer: kAdminContact, peerName: 'Администратор'),
                                )),
                        icon: const Icon(Icons.chat_bubble_outline),
                        label: const Text('Написать администратору'),
                      ),
                    ]),
                  ),
                ],
                const SizedBox(height: 18),
                const _Perk(Icons.history_toggle_off, 'Истории на 24 часа', 'Публикуй текст на цветном фоне', true),
                const _Perk(Icons.palette_outlined, 'Цветной ник', 'Виден всем в чатах и историях', true),
                const _Perk(Icons.workspace_premium, 'Значок премиума', 'Рядом с именем в профиле', true),
                const _Perk(Icons.auto_awesome, 'Своя заставка при входе', 'Три стиля на выбор', true),
                const _Perk(Icons.emoji_emotions_outlined, 'Свои эмодзи, стикеры и GIF', 'Скоро', false),
                const _Perk(Icons.video_library_outlined, 'Своё видео вместо заставки', 'Скоро', false),
                const SizedBox(height: 18),
                const Text('Заставка при входе',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                for (final st in kIntroStyles) _IntroTile(style: st, onPreview: _preview),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _Perk extends StatelessWidget {
  final IconData icon;
  final String title, note;
  final bool ready;
  const _Perk(this.icon, this.title, this.note, this.ready);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(children: [
        Icon(icon, color: ready ? NebulaColors.accent2 : NebulaColors.textDim),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
            Text(note, style: const TextStyle(color: NebulaColors.textDim, fontSize: 12)),
          ]),
        ),
      ]),
    );
  }
}

class _IntroTile extends StatelessWidget {
  final IntroStyle style;
  final void Function(BuildContext, String) onPreview;
  const _IntroTile({required this.style, required this.onPreview});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    final selected = s.intro == style.id;
    final locked = !s.premium && style.id != 'eye';
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
      decoration: BoxDecoration(
        color: NebulaColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: selected ? NebulaColors.accent : Colors.white12,
          width: selected ? 2 : 1,
        ),
      ),
      child: Row(children: [
        Expanded(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              if (locked) {
                ScaffoldMessenger.of(context)
                  ..hideCurrentSnackBar()
                  ..showSnackBar(const SnackBar(content: Text('Этот стиль доступен с премиумом')));
              } else {
                s.setIntro(style.id);
              }
            },
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text(style.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(width: 6),
                if (locked) const Icon(Icons.lock_outline, size: 15, color: NebulaColors.textDim),
                if (selected) const Icon(Icons.check_circle, size: 16, color: NebulaColors.accent),
              ]),
              const SizedBox(height: 2),
              Text(style.note, style: const TextStyle(color: NebulaColors.textDim, fontSize: 12)),
            ]),
          ),
        ),
        IconButton(
          tooltip: 'Посмотреть',
          icon: const Icon(Icons.play_circle_outline, color: NebulaColors.accent2),
          onPressed: () => onPreview(context, style.id),
        ),
      ]),
    );
  }
}
