import 'package:flutter/material.dart';

import '../app_state.dart';
import '../theme.dart';

const List<String> kAvatarEmojis = [
  '🦊', '🐼', '🐱', '🐸', '🦄', '🐙', '🦋', '🐬',
  '🚀', '⭐', '🌙', '🔥', '🌸', '🍀', '👾', '🎧',
];

const List<String> kNickColors = [
  '#FF7AC8', '#FFB02E', '#FFD86B', '#7CFFB2', '#22D3EE', '#7C9CFF', '#B58CFF', '#FF6B6B',
];

/// Редактирование профиля: имя, аватар, цвет ника (премиум), пароль.
class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late final TextEditingController _name = TextEditingController(text: AppState.I.displayName);
  final _old = TextEditingController();
  final _new = TextEditingController();
  double _hue = 250;
  String _emoji = '';

  @override
  void initState() {
    super.initState();
    final parts = AppState.I.lookOf(AppState.I.username).avatar.split('|');
    if (parts.length == 2) {
      _emoji = parts[0];
      _hue = double.tryParse(parts[1]) ?? 250;
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _old.dispose();
    _new.dispose();
    super.dispose();
  }

  void _saveLook() {
    AppState.I.updateProfile(
      displayName: _name.text.trim().isEmpty ? null : _name.text.trim(),
      avatar: _emoji.isEmpty ? '' : '$_emoji|${_hue.round()}',
    );
    _toast('Сохранено');
  }

  void _toast(String t) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(t)));
  }

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    final preview = _emoji.isEmpty ? '' : '$_emoji|${_hue.round()}';
    return SpaceBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: const Text('Редактировать профиль'),
        ),
        body: AnimatedBuilder(
          animation: s,
          builder: (context, _) => ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
            children: [
              Center(child: _PreviewAvatar(name: _name.text, avatar: preview)),
              const SizedBox(height: 18),
              TextField(
                controller: _name,
                maxLength: 40,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  hintText: 'Ник',
                  counterText: '',
                  prefixIcon: Icon(Icons.badge_outlined, color: NebulaColors.textDim),
                ),
              ),
              const SizedBox(height: 14),
              const Text('Аватар', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final e in kAvatarEmojis)
                  GestureDetector(
                    onTap: () => setState(() => _emoji = _emoji == e ? '' : e),
                    child: Container(
                      width: 46,
                      height: 46,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: NebulaColors.surface,
                        border: Border.all(
                          color: _emoji == e ? NebulaColors.accent : Colors.white12,
                          width: _emoji == e ? 2 : 1,
                        ),
                      ),
                      child: Text(e, style: const TextStyle(fontSize: 24)),
                    ),
                  ),
              ]),
              const SizedBox(height: 6),
              Slider(
                value: _hue,
                min: 0,
                max: 359,
                activeColor: HSLColor.fromAHSL(1, _hue, .7, .55).toColor(),
                onChanged: (v) => setState(() => _hue = v),
              ),
              const Text('Цвет фона аватара',
                  style: TextStyle(color: NebulaColors.textDim, fontSize: 12)),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: FilledButton(onPressed: _saveLook, child: const Text('Сохранить')),
              ),
              const SizedBox(height: 26),
              Row(children: [
                const Text('Цвет ника', style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(width: 8),
                if (!s.premium)
                  const Icon(Icons.lock_outline, size: 16, color: NebulaColors.textDim),
              ]),
              const SizedBox(height: 4),
              Text(
                s.premium ? 'Виден всем в чатах и историях' : 'Доступно с премиумом',
                style: const TextStyle(color: NebulaColors.textDim, fontSize: 12),
              ),
              const SizedBox(height: 10),
              Wrap(spacing: 10, runSpacing: 10, children: [
                GestureDetector(
                  onTap: s.premium ? () => s.updateProfile(nickColor: '') : null,
                  child: _Dot(color: null, locked: !s.premium),
                ),
                for (final hex in kNickColors)
                  GestureDetector(
                    onTap: s.premium
                        ? () => s.updateProfile(nickColor: hex)
                        : () => _toast('Цветной ник доступен с премиумом'),
                    child: _Dot(
                      color: Color(0xFF000000 | int.parse(hex.substring(1), radix: 16)),
                      locked: !s.premium,
                      selected: s.lookOf(s.username).nickColor.toUpperCase() == hex,
                    ),
                  ),
              ]),
              const SizedBox(height: 28),
              const Text('Сменить пароль', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              TextField(
                controller: _old,
                obscureText: true,
                decoration: const InputDecoration(
                  hintText: 'Старый пароль',
                  prefixIcon: Icon(Icons.lock_outline, color: NebulaColors.textDim),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _new,
                obscureText: true,
                decoration: const InputDecoration(
                  hintText: 'Новый пароль (от 6 символов)',
                  prefixIcon: Icon(Icons.lock_reset, color: NebulaColors.textDim),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () {
                    if (_old.text.isEmpty || _new.text.isEmpty) return;
                    s.changePassword(_old.text, _new.text);
                    _old.clear();
                    _new.clear();
                  },
                  child: const Text('Сменить пароль'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PreviewAvatar extends StatelessWidget {
  final String name, avatar;
  const _PreviewAvatar({required this.name, required this.avatar});

  @override
  Widget build(BuildContext context) {
    final parts = avatar.split('|');
    final has = parts.length == 2;
    final hue = has ? (double.tryParse(parts[1]) ?? 250) : 250.0;
    final c1 = HSLColor.fromAHSL(1, hue, .7, .55).toColor();
    final c2 = HSLColor.fromAHSL(1, (hue + 50) % 360, .75, .4).toColor();
    return Container(
      width: 104,
      height: 104,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(colors: [c1, c2], begin: Alignment.topLeft, end: Alignment.bottomRight),
      ),
      child: has
          ? Text(parts[0], style: const TextStyle(fontSize: 52))
          : NebulaAvatar(name: name, size: 104),
    );
  }
}

class _Dot extends StatelessWidget {
  final Color? color;
  final bool locked, selected;
  const _Dot({required this.color, this.locked = false, this.selected = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 36,
      height: 36,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color ?? NebulaColors.surface,
        border: Border.all(color: selected ? Colors.white : Colors.white24, width: selected ? 3 : 1),
      ),
      child: color == null
          ? const Icon(Icons.block, size: 18, color: NebulaColors.textDim)
          : (locked ? const Icon(Icons.lock, size: 14, color: Colors.black54) : null),
    );
  }
}
