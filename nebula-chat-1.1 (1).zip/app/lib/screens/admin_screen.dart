import 'package:flutter/material.dart';

import '../app_state.dart';
import '../theme.dart';

/// Админ-панель: список пользователей и выдача премиума.
class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  final _q = TextEditingController();

  @override
  void initState() {
    super.initState();
    AppState.I.adminLoad('');
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SpaceBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: const Text('Админ-панель'),
        ),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: TextField(
              controller: _q,
              onChanged: AppState.I.adminLoad,
              decoration: const InputDecoration(
                hintText: 'Найти пользователя',
                prefixIcon: Icon(Icons.search, color: NebulaColors.textDim),
              ),
            ),
          ),
          Expanded(
            child: AnimatedBuilder(
              animation: AppState.I,
              builder: (context, _) {
                final list = AppState.I.adminUsers;
                if (list.isEmpty) {
                  return const Center(
                    child: Text('Пока никого нет', style: TextStyle(color: NebulaColors.textDim)),
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  itemCount: list.length + 1,
                  itemBuilder: (context, i) {
                    if (i == 0) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Text(
                          'Всего: ${AppState.I.adminTotal}. Включи переключатель, чтобы выдать премиум.',
                          style: const TextStyle(color: NebulaColors.textDim, fontSize: 12),
                        ),
                      );
                    }
                    final u = list[i - 1];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: NebulaColors.surface,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: ListTile(
                        leading: NebulaAvatar(name: u.displayName, user: u.username, size: 40),
                        title: Row(children: [
                          Flexible(
                            child: Text(u.displayName,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.w700)),
                          ),
                          if (u.admin)
                            const Padding(
                              padding: EdgeInsets.only(left: 6),
                              child: Icon(Icons.shield_outlined, size: 15, color: NebulaColors.accent2),
                            ),
                        ]),
                        subtitle: Text(
                          '@${u.username}${u.online ? ' · в сети' : ''}',
                          style: const TextStyle(color: NebulaColors.textDim, fontSize: 12),
                        ),
                        trailing: Switch(
                          value: u.premium,
                          onChanged: u.admin
                              ? null
                              : (v) => AppState.I.adminSetPremium(u.username, v),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ]),
      ),
    );
  }
}
