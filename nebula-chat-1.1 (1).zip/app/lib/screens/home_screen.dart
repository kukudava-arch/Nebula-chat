import 'dart:async';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../theme.dart';
import 'calls_tab.dart';
import 'chats_tab.dart';
import 'market_tab.dart';
import 'profile_tab.dart';
import 'search_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  int _tab = 0;
  StreamSubscription<String>? _errSub;

  static const _tabs = <Widget>[
    ChatsTab(),
    CallsTab(),
    MarketTab(),
    ProfileTab(),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _errSub = AppState.I.errors.listen((e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(e)));
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _errSub?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      AppState.I.ensureConnected();
      AppState.I.loadStories();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SpaceBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          bottom: false,
          child: Column(
            children: [
              const _ConnectionBanner(),
              Expanded(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 280),
                  switchInCurve: Curves.easeOutCubic,
                  transitionBuilder: (child, anim) => FadeTransition(
                    opacity: anim,
                    child: SlideTransition(
                      position: Tween<Offset>(
                        begin: const Offset(0, 0.02),
                        end: Offset.zero,
                      ).animate(anim),
                      child: child,
                    ),
                  ),
                  child: KeyedSubtree(key: ValueKey(_tab), child: _tabs[_tab]),
                ),
              ),
            ],
          ),
        ),
        floatingActionButton: _tab == 0
            ? Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: NebulaColors.gradient,
                  boxShadow: [
                    BoxShadow(
                      color: NebulaColors.accent.withValues(alpha: 0.45),
                      blurRadius: 18,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: FloatingActionButton(
                  backgroundColor: Colors.transparent,
                  elevation: 0,
                  focusElevation: 0,
                  hoverElevation: 0,
                  highlightElevation: 0,
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => const SearchScreen()),
                  ),
                  child: const Icon(Icons.edit_outlined, color: Colors.white),
                ),
              )
            : null,
        bottomNavigationBar: NavigationBar(
          backgroundColor: NebulaColors.bgDeep.withValues(alpha: 0.94),
          indicatorColor: NebulaColors.accent.withValues(alpha: 0.28),
          selectedIndex: _tab,
          onDestinationSelected: (i) => setState(() => _tab = i),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.chat_bubble_outline),
              selectedIcon: Icon(Icons.chat_bubble),
              label: 'Чаты',
            ),
            NavigationDestination(
              icon: Icon(Icons.call_outlined),
              selectedIcon: Icon(Icons.call),
              label: 'Звонки',
            ),
            NavigationDestination(
              icon: Icon(Icons.storefront_outlined),
              selectedIcon: Icon(Icons.storefront),
              label: 'Маркет',
            ),
            NavigationDestination(
              icon: Icon(Icons.person_outline),
              selectedIcon: Icon(Icons.person),
              label: 'Профиль',
            ),
          ],
        ),
      ),
    );
  }
}

/// Полоска «Подключение…», пока нет связи с сервером.
class _ConnectionBanner extends StatelessWidget {
  const _ConnectionBanner();

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.I,
      builder: (context, _) {
        final offline = !AppState.I.connected;
        return ClipRect(
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut,
            height: offline ? 28 : 0,
            width: double.infinity,
            color: NebulaColors.surfaceHi,
            alignment: Alignment.center,
            child: offline
                ? const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 12,
                        height: 12,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: NebulaColors.accent2),
                      ),
                      SizedBox(width: 8),
                      Text('Подключение…',
                          style: TextStyle(fontSize: 12, color: NebulaColors.textDim)),
                    ],
                  )
                : null,
          ),
        );
      },
    );
  }
}
