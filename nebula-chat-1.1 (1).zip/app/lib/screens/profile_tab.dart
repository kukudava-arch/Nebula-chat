import 'package:flutter/material.dart';

import '../app_state.dart';
import '../helper/helper_models.dart';
import '../helper/helper_service.dart';
import '../theme.dart';
import 'admin_screen.dart';
import 'edit_profile_screen.dart';
import 'premium_screen.dart';

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  Future<void> _confirmLogout(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: NebulaColors.surface,
        title: const Text('Выйти из аккаунта?'),
        content: const Text('История звонков на этом устройстве будет очищена.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Выйти', style: TextStyle(color: NebulaColors.danger)),
          ),
        ],
      ),
    );
    if (ok == true) await AppState.I.logout();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.I,
      builder: (context, _) {
        final s = AppState.I;
        return ListView(
          padding: const EdgeInsets.fromLTRB(20, 28, 20, 24),
          children: [
            Center(child: NebulaAvatar(name: s.displayName, user: s.username, size: 104)),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Flexible(
                  child: Text(
                    s.displayName,
                    textAlign: TextAlign.center,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
                  ),
                ),
                if (s.premium)
                  const Padding(
                    padding: EdgeInsets.only(left: 8),
                    child: Icon(Icons.workspace_premium, color: Color(0xFFFFC857)),
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              '@${s.username}',
              textAlign: TextAlign.center,
              style: const TextStyle(color: NebulaColors.textDim),
            ),
            const SizedBox(height: 28),
            _InfoCard(
              icon: Icons.dns_outlined,
              title: 'Сервер',
              value: s.serverUrl,
              trailing: Icon(
                Icons.circle,
                size: 12,
                color: s.connected ? NebulaColors.success : NebulaColors.danger,
              ),
            ),
            const SizedBox(height: 12),
            _NavCard(
              icon: Icons.edit_outlined,
              title: 'Редактировать профиль',
              value: 'Ник, аватар, цвет ника, пароль',
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute<void>(builder: (_) => const EditProfileScreen())),
            ),
            const SizedBox(height: 12),
            _NavCard(
              icon: Icons.workspace_premium,
              title: s.premium ? 'Премиум включён' : 'Nebula Премиум · 399 ₽',
              value: s.premium
                  ? 'Заставка при входе и другие плюшки'
                  : 'Своя заставка при входе, скоро истории',
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute<void>(builder: (_) => const PremiumScreen())),
            ),
            if (s.admin) ...[
              const SizedBox(height: 12),
              _NavCard(
                icon: Icons.admin_panel_settings_outlined,
                title: 'Админ-панель',
                value: 'Пользователи и выдача премиума',
                onTap: () => Navigator.of(context)
                    .push(MaterialPageRoute<void>(builder: (_) => const AdminScreen())),
              ),
            ],
            const SizedBox(height: 12),
            const _InfoCard(
              icon: Icons.sell_outlined,
              title: 'Мои объявления',
              value: 'Скоро: витрина товаров в вашем профиле',
            ),
            const SizedBox(height: 12),
            AnimatedBuilder(
              animation: HelperService.I,
              builder: (context, _) {
                final h = HelperService.I;
                String nm(String id) => kHelperModels.firstWhere((m) => m.id == id).name;
                return Container(
                  decoration: BoxDecoration(
                    color: NebulaColors.surface,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(children: [
                    SwitchListTile(
                      title: const Text('Звёздочка'),
                      subtitle: Text(nm(h.starModel)),
                      value: h.starOn,
                      onChanged: h.setStarOn,
                    ),
                    SwitchListTile(
                      title: const Text('Пузырёк'),
                      subtitle: Text(nm(h.bubbleModel)),
                      value: h.bubbleOn,
                      onChanged: h.setBubbleOn,
                    ),
                    const Padding(
                      padding: EdgeInsets.fromLTRB(16, 0, 16, 12),
                      child: Text('Нажми на помощника — он ответит. Удерживай — выбрать модельку. Перетащи — переставить.',
                          style: TextStyle(fontSize: 12, color: NebulaColors.textDim)),
                    ),
                  ]),
                );
              },
            ),
            const SizedBox(height: 28),
            OutlinedButton.icon(
              onPressed: () => _confirmLogout(context),
              icon: const Icon(Icons.logout, color: NebulaColors.danger),
              label: const Text('Выйти', style: TextStyle(color: NebulaColors.danger)),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                side: BorderSide(color: NebulaColors.danger.withValues(alpha: 0.5)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Nebula Chat · версия 1.1',
              textAlign: TextAlign.center,
              style: TextStyle(color: NebulaColors.textDim, fontSize: 12),
            ),
          ],
        );
      },
    );
  }
}

class _NavCard extends StatelessWidget {
  final IconData icon;
  final String title, value;
  final VoidCallback onTap;
  const _NavCard({required this.icon, required this.title, required this.value, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: NebulaColors.surface,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            Icon(icon, color: NebulaColors.accent2),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(value, style: const TextStyle(color: NebulaColors.textDim, fontSize: 12)),
              ]),
            ),
            const Icon(Icons.chevron_right, color: NebulaColors.textDim),
          ]),
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String title, value;
  final Widget? trailing;
  const _InfoCard({required this.icon, required this.title, required this.value, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: NebulaColors.surface.withValues(alpha: 0.85),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Icon(icon, color: NebulaColors.accent2),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 3),
                Text(
                  value,
                  style: const TextStyle(color: NebulaColors.textDim, fontSize: 13),
                ),
              ],
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}
