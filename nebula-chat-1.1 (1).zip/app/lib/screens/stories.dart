import 'package:flutter/material.dart';

import '../app_state.dart';
import '../theme.dart';

const List<List<Color>> kStoryBgs = [
  [Color(0xFF7C5CFF), Color(0xFF22D3EE)],
  [Color(0xFFFF4D9A), Color(0xFF7C5CFF)],
  [Color(0xFF0F2027), Color(0xFF2C5364)],
  [Color(0xFFFF8A3D), Color(0xFFFF4D6D)],
  [Color(0xFF11998E), Color(0xFF38EF7D)],
  [Color(0xFF141E30), Color(0xFF243B55)],
  [Color(0xFFF7971E), Color(0xFFFFD200)],
  [Color(0xFF8E2DE2), Color(0xFF4A00E0)],
];

/// Полоска историй над списком чатов.
class StoriesBar extends StatelessWidget {
  const StoriesBar({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    // группируем по пользователю, свои идут первыми
    final byUser = <String, List<Story>>{};
    for (final st in s.stories) {
      byUser.putIfAbsent(st.user, () => []).add(st);
    }
    final users = byUser.keys.toList()
      ..sort((a, b) {
        if (a == s.username) return -1;
        if (b == s.username) return 1;
        return byUser[b]!.last.ts.compareTo(byUser[a]!.last.ts);
      });
    return SizedBox(
      height: 92,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: [
          _Bubble(
            label: 'Моя история',
            onTap: () => _compose(context),
            child: Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: NebulaColors.accent2, width: 2),
              ),
              child: const Icon(Icons.add, color: NebulaColors.accent2),
            ),
          ),
          for (final u in users)
            _Bubble(
              label: u == s.username ? 'Вы' : byUser[u]!.first.name,
              onTap: () => Navigator.of(context).push(
                PageRouteBuilder<void>(
                  opaque: false,
                  transitionDuration: const Duration(milliseconds: 250),
                  pageBuilder: (_, __, ___) => StoryViewer(stories: byUser[u]!),
                  transitionsBuilder: (_, a, __, c) => FadeTransition(opacity: a, child: c),
                ),
              ),
              child: Container(
                padding: const EdgeInsets.all(3),
                decoration: const BoxDecoration(shape: BoxShape.circle, gradient: NebulaColors.gradient),
                child: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF0B0B1E)),
                  child: NebulaAvatar(name: byUser[u]!.first.name, user: u, size: 48),
                ),
              ),
            ),
        ],
      ),
    );
  }

  void _compose(BuildContext context) {
    if (!AppState.I.premium) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('Истории доступны с премиумом')));
      return;
    }
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: NebulaColors.surface,
      builder: (_) => const _Composer(),
    );
  }
}

class _Bubble extends StatelessWidget {
  final Widget child;
  final String label;
  final VoidCallback onTap;
  const _Bubble({required this.child, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 72,
        margin: const EdgeInsets.only(right: 6),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          child,
          const SizedBox(height: 6),
          Text(label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11, color: NebulaColors.textDim)),
        ]),
      ),
    );
  }
}

class _Composer extends StatefulWidget {
  const _Composer();

  @override
  State<_Composer> createState() => _ComposerState();
}

class _ComposerState extends State<_Composer> {
  final _text = TextEditingController();
  int _bg = 0;

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final inset = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 16, 20, 20 + inset),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Новая история', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        Container(
          height: 150,
          alignment: Alignment.center,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(colors: kStoryBgs[_bg]),
          ),
          child: TextField(
            controller: _text,
            maxLength: 200,
            maxLines: null,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: Colors.white),
            decoration: const InputDecoration(
              hintText: 'Напиши что-нибудь…',
              counterText: '',
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              filled: false,
            ),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 38,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: kStoryBgs.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, i) => GestureDetector(
              onTap: () => setState(() => _bg = i),
              child: Container(
                width: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(colors: kStoryBgs[i]),
                  border: Border.all(color: i == _bg ? Colors.white : Colors.transparent, width: 2),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            onPressed: () {
              final t = _text.text.trim();
              if (t.isEmpty) return;
              AppState.I.postStory(t, _bg);
              Navigator.pop(context);
            },
            child: const Text('Опубликовать на 24 часа'),
          ),
        ),
      ]),
    );
  }
}

/// Просмотр историй одного пользователя: нажми, чтобы листать; вниз — закрыть.
class StoryViewer extends StatefulWidget {
  final List<Story> stories;
  const StoryViewer({super.key, required this.stories});

  @override
  State<StoryViewer> createState() => _StoryViewerState();
}

class _StoryViewerState extends State<StoryViewer> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  int _i = 0;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(seconds: 5))
      ..addStatusListener((st) {
        if (st == AnimationStatus.completed) _next();
      })
      ..forward();
  }

  void _next() {
    if (_i + 1 >= widget.stories.length) {
      Navigator.of(context).maybePop();
    } else {
      setState(() => _i++);
      _c.forward(from: 0);
    }
  }

  void _prev() {
    if (_i > 0) {
      setState(() => _i--);
    }
    _c.forward(from: 0);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final st = widget.stories[_i];
    final mine = st.user == AppState.I.username;
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapUp: (d) =>
            d.localPosition.dx < MediaQuery.of(context).size.width / 3 ? _prev() : _next(),
        onVerticalDragEnd: (d) {
          if ((d.primaryVelocity ?? 0) > 200) Navigator.of(context).maybePop();
        },
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: kStoryBgs[st.bg.clamp(0, kStoryBgs.length - 1)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: SafeArea(
            child: Stack(children: [
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Text(
                    st.text,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 28, fontWeight: FontWeight.w800, color: Colors.white, height: 1.3),
                  ),
                ),
              ),
              Positioned(
                left: 12,
                right: 12,
                top: 8,
                child: Column(children: [
                  Row(children: [
                    for (var k = 0; k < widget.stories.length; k++)
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 2),
                          child: AnimatedBuilder(
                            animation: _c,
                            builder: (_, __) => LinearProgressIndicator(
                              value: k < _i ? 1 : (k == _i ? _c.value : 0),
                              minHeight: 3,
                              backgroundColor: Colors.white30,
                              valueColor: const AlwaysStoppedAnimation(Colors.white),
                            ),
                          ),
                        ),
                      ),
                  ]),
                  const SizedBox(height: 10),
                  Row(children: [
                    NebulaAvatar(name: st.name, user: st.user, size: 34),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(st.name,
                          style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.white)),
                    ),
                    if (mine || AppState.I.admin)
                      IconButton(
                        icon: const Icon(Icons.delete_outline, color: Colors.white),
                        onPressed: () {
                          AppState.I.deleteStory(st.id);
                          Navigator.of(context).maybePop();
                        },
                      ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white),
                      onPressed: () => Navigator.of(context).maybePop(),
                    ),
                  ]),
                ]),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
