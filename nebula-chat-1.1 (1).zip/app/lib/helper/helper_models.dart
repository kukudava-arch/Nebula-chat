import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart' show Ticker;

const double _pi = math.pi;
const double _tau = math.pi * 2;

Color _hsl(double h, double s, double l, [double a = 1]) => HSLColor.fromAHSL(
      a.clamp(0.0, 1.0).toDouble(),
      ((h % 360) + 360) % 360,
      (s / 100).clamp(0.0, 1.0).toDouble(),
      (l / 100).clamp(0.0, 1.0).toDouble(),
    ).toColor();

class HelperModel {
  final String id;
  final String name;
  final bool bubble;
  const HelperModel(this.id, this.name, {this.bubble = false});
}

const List<HelperModel> kHelperModels = [
  HelperModel('classic', 'Классическая звезда'),
  HelperModel('moon', 'Лунный камень'),
  HelperModel('comet', 'Комета'),
  HelperModel('popstar', 'Голографическая поп-звезда'),
  HelperModel('cat', 'Звёздный кот'),
  HelperModel('bee', 'Медовая пчела'),
  HelperModel('fire', 'Огненная звезда'),
  HelperModel('ice', 'Ледяная звезда'),
  HelperModel('rose', 'Розовая мечтательница'),
  HelperModel('soap', 'Мыльный пузырь', bubble: true),
  HelperModel('drop', 'Капелька', bubble: true),
  HelperModel('chorus', 'Пузырёк-подпевала', bubble: true),
  HelperModel('berry', 'Ягодный пузырёк', bubble: true),
  HelperModel('mint', 'Мятный пузырёк', bubble: true),
  HelperModel('galaxy', 'Галактический пузырёк', bubble: true),
];

/// Общие часы для всех анимаций помощника (секунды с запуска).
class HelperClock extends ValueNotifier<double> {
  HelperClock._() : super(0);
  static final HelperClock I = HelperClock._();
  Ticker? _ticker;

  void start() {
    _ticker ??= Ticker((Duration d) {
      value = d.inMicroseconds / 1e6;
    })
      ..start();
  }
}

/// Рисует выбранную модель в квадрате size x size.
class HelperPainter extends CustomPainter {
  final String model;
  final double t;
  HelperPainter(this.model, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final u = size.width / 2 * .9;
    canvas.save();
    canvas.translate(size.width / 2, size.height / 2 + math.sin(t * 1.6) * .03 * u);
    canvas.scale(u);
    switch (model) {
      case 'moon':
        _moon(canvas, t);
        break;
      case 'comet':
        _comet(canvas, t);
        break;
      case 'popstar':
        _pop(canvas, t);
        break;
      case 'cat':
        _cat(canvas, t);
        break;
      case 'bee':
        _bee(canvas, t);
        break;
      case 'soap':
        _soap(canvas, t);
        break;
      case 'drop':
        _drop(canvas, t);
        break;
      case 'chorus':
        _chorus(canvas, t);
        break;
      case 'fire':
        _star(canvas, t, h: 14, s: 100, l: 58, eye: 'wide', faceColor: const Color(0xFF4A1204));
        break;
      case 'ice':
        _star(canvas, t, h: 195, s: 85, l: 76, eye: 'sleepy', faceColor: const Color(0xFF123A5A));
        break;
      case 'rose':
        _star(canvas, t, h: 335, s: 88, l: 72, eye: 'anime', eyeHue: 330, faceColor: const Color(0xFF5A1236));
        break;
      case 'berry':
        _soap(canvas, t, 330, 'anime');
        break;
      case 'mint':
        _soap(canvas, t, 150, 'happy');
        break;
      case 'galaxy':
        _galaxy(canvas, t);
        break;
      default:
        _star(canvas, t);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(HelperPainter old) => old.t != t || old.model != model;
}

// ---------- общие кусочки ----------

void _glow(Canvas c, double x, double y, double r, Color col, {bool plus = false}) {
  final p = Paint()
    ..shader = ui.Gradient.radial(Offset(x, y), r, [col, col.withValues(alpha: 0)]);
  if (plus) p.blendMode = BlendMode.plus;
  c.drawCircle(Offset(x, y), r, p);
}

void _spark(Canvas c, double x, double y, double s, Color col) {
  final p = Path()
    ..moveTo(x, y - s)
    ..quadraticBezierTo(x, y, x + s, y)
    ..quadraticBezierTo(x, y, x, y + s)
    ..quadraticBezierTo(x, y, x - s, y)
    ..quadraticBezierTo(x, y, x, y - s)
    ..close();
  c.drawPath(p, Paint()..color = col);
}

Path _starPath(int n, double ro, double ri) {
  final pts = <Offset>[];
  for (var i = 0; i < n * 2; i++) {
    final r = i.isOdd ? ri : ro;
    final a = -_pi / 2 + i * _pi / n;
    pts.add(Offset(math.cos(a) * r, math.sin(a) * r));
  }
  Offset mid(Offset a, Offset b) => Offset((a.dx + b.dx) / 2, (a.dy + b.dy) / 2);
  final path = Path();
  final s = mid(pts.last, pts.first);
  path.moveTo(s.dx, s.dy);
  for (var i = 0; i < pts.length; i++) {
    final e = mid(pts[i], pts[(i + 1) % pts.length]);
    path.quadraticBezierTo(pts[i].dx, pts[i].dy, e.dx, e.dy);
  }
  path.close();
  return path;
}

Rect _oval(double cx, double cy, double rx, double ry) =>
    Rect.fromCenter(center: Offset(cx, cy), width: rx * 2, height: ry * 2);

void _face(Canvas c, double t, double x, double y, double k, String style, double hue, Color col) {
  final b = (t % 4.2) < .14 ? .12 : 1.0;
  c.save();
  c.translate(x, y);
  c.scale(k);
  final fill = Paint()..color = col;
  final line = Paint()
    ..color = col
    ..style = PaintingStyle.stroke
    ..strokeWidth = .03
    ..strokeCap = StrokeCap.round;
  var mouth = 'smile';
  const eyesX = [-.13, .13];
  switch (style) {
    case 'anime':
      for (final ex in eyesX) {
        c.drawOval(_oval(ex, 0, .07, .09 * b), Paint()..color = Colors.white);
        c.drawOval(
          _oval(ex, .005, .052, .075 * b),
          Paint()
            ..shader = ui.Gradient.linear(
              Offset(ex, -.09),
              Offset(ex, .09),
              [_hsl(hue, 90, 32), _hsl(hue, 95, 68)],
            ),
        );
        c.drawOval(_oval(ex, .01, .026, .04 * b), Paint()..color = const Color(0xFF10102A));
        c.drawCircle(Offset(ex - .02, -.03 * b), .016, Paint()..color = Colors.white);
        c.drawCircle(Offset(ex + .02, .03 * b), .008, Paint()..color = Colors.white);
        c.drawArc(Rect.fromCircle(center: Offset(ex, 0), radius: .078), _pi * 1.08, _pi * .84,
            false, line..strokeWidth = .024);
      }
      break;
    case 'happy':
      for (final ex in eyesX) {
        c.drawArc(Rect.fromCircle(center: Offset(ex, .02), radius: .05), _pi * 1.1, _pi * .8,
            false, line);
      }
      break;
    case 'sleepy':
      for (final ex in eyesX) {
        c.drawArc(Rect.fromCircle(center: Offset(ex, -.015), radius: .05), _pi * .1, _pi * .8,
            false, line);
      }
      mouth = 'tiny';
      break;
    case 'cat':
      for (final ex in eyesX) {
        c.drawOval(_oval(ex, 0, .055, .07 * b), Paint()..color = const Color(0xFFFFE36B));
        c.drawOval(_oval(ex, 0, .014, .062 * b), Paint()..color = const Color(0xFF1A1230));
      }
      mouth = 'w';
      break;
    case 'wide':
      for (final ex in eyesX) {
        c.drawOval(_oval(ex, 0, .065, .075 * b), Paint()..color = Colors.white);
        c.drawCircle(Offset(ex + math.sin(t * .9) * .02, math.cos(t * .7) * .015), .03,
            Paint()..color = const Color(0xFF1A1230));
      }
      mouth = 'o';
      break;
    default:
      for (final ex in eyesX) {
        c.drawOval(_oval(ex, 0, .04, .05 * b), fill);
      }
  }
  line.strokeWidth = .025;
  if (mouth == 'smile') {
    c.drawArc(Rect.fromCircle(center: const Offset(0, .05), radius: .07), _pi * .15, _pi * .7,
        false, line);
  } else if (mouth == 'tiny') {
    c.drawArc(Rect.fromCircle(center: const Offset(0, .07), radius: .03), _pi * .15, _pi * .7,
        false, line);
  } else if (mouth == 'o') {
    c.drawOval(_oval(0, .11, .025, .03), fill);
  } else if (mouth == 'w') {
    c.drawArc(Rect.fromCircle(center: const Offset(-.03, .08), radius: .03), _pi * .1, _pi * .8,
        false, line);
    c.drawArc(Rect.fromCircle(center: const Offset(.03, .08), radius: .03), _pi * .1, _pi * .8,
        false, line);
  }
  c.restore();
}

void _phones(Canvas c, double t, double h, double rad, double cy) {
  final r = rad + .04;
  final rect = Rect.fromCircle(center: Offset(0, cy), radius: r);
  c.drawArc(
    rect,
    _pi * 1.1,
    _pi * .8,
    false,
    Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = .07
      ..color = _hsl(h, 40, 22),
  );
  c.drawArc(
    rect,
    _pi * 1.1,
    _pi * .8,
    false,
    Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = .022
      ..color = _hsl(h, 80, 70, .7),
  );
  for (final sx in const [-1.0, 1.0]) {
    c.save();
    c.translate(sx * r * .951, cy - r * .309);
    c.rotate(sx * .15);
    final o = Rect.fromCenter(center: Offset.zero, width: .16, height: .28);
    c.drawOval(o, Paint()..color = _hsl(h, 55, 28));
    c.drawOval(
      o,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .02
        ..color = _hsl(h, 80, 75, .8),
    );
    c.drawOval(Rect.fromCenter(center: Offset.zero, width: .09, height: .19),
        Paint()..color = _hsl(h, 95, 62, .55 + .3 * math.sin(t * 4)));
    c.restore();
  }
}

void _glass(Canvas c, double t, double r, double h) {
  final a0 = t * .5;
  c.drawCircle(
    Offset.zero,
    r,
    Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .03
      ..shader = ui.Gradient.sweep(
        Offset.zero,
        [
          _hsl(h, 90, 75, .8),
          _hsl(h + 60, 90, 75, .8),
          _hsl(h + 140, 90, 75, .8),
          _hsl(h + 220, 90, 75, .8),
          _hsl(h + 300, 90, 75, .8),
          _hsl(h, 90, 75, .8),
        ],
        const [0.0, .2, .4, .6, .8, 1.0],
        TileMode.clamp,
        a0,
        a0 + _tau,
      ),
  );
  c.save();
  c.translate(-r * .42, -r * .48);
  c.rotate(-.7);
  c.drawOval(Rect.fromCenter(center: Offset.zero, width: r * .4, height: r * .2),
      Paint()..color = const Color(0xB3FFFFFF));
  c.restore();
  c.drawCircle(Offset(r * .5, r * .5), r * .05, Paint()..color = const Color(0x66FFFFFF));
}

// ---------- звёздочки ----------

void _star(
  Canvas c,
  double t, {
  double h = 46,
  double s = 96,
  double l = 60,
  double ro = .7,
  double ri = .36,
  bool glow = true,
  bool withFace = true,
  String eye = 'dot',
  double eyeHue = 200,
  Color faceColor = const Color(0xFF231A4A),
}) {
  if (glow) _glow(c, 0, 0, .95, _hsl(h, s, l, .28));
  c.save();
  c.rotate(math.sin(t * .6) * .1);
  final path = _starPath(5, ro, ri);
  c.drawPath(
    path,
    Paint()
      ..shader = ui.Gradient.linear(
        const Offset(-.4, -.6),
        const Offset(.4, .6),
        [_hsl(h, s, l + 20), _hsl(h, s, l - 14)],
      ),
  );
  c.drawPath(
    path,
    Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .03
      ..strokeJoin = StrokeJoin.round
      ..color = _hsl(h, s, l + 30, .75),
  );
  c.save();
  c.translate(-.17, -.2);
  c.rotate(-.7);
  c.drawOval(Rect.fromCenter(center: Offset.zero, width: .2, height: .11),
      Paint()..color = const Color(0x8CFFFFFF));
  c.restore();
  c.restore();
  if (withFace) _face(c, t, 0, .04, 1, eye, eyeHue, faceColor);
}

void _moon(Canvas c, double t) {
  const r = .58;
  _glow(c, 0, 0, .9, _hsl(220, 30, 80, .25));
  c.drawCircle(
    Offset.zero,
    r,
    Paint()
      ..shader = ui.Gradient.radial(
        const Offset(-.2, -.22),
        r * 1.4,
        const [Color(0xFFF2F3FB), Color(0xFFB5B9D0), Color(0xFF6F7390)],
        const [0.0, .6, 1.0],
      ),
  );
  c.save();
  c.clipPath(Path()..addOval(Rect.fromCircle(center: Offset.zero, radius: r)));
  const craters = [
    [.2, .1, .16],
    [1.4, -.35, .12],
    [2.6, .25, .2],
    [3.8, -.1, .11],
    [5.0, .4, .14],
  ];
  for (final cr in craters) {
    final a = cr[0] + t * .35;
    final k = math.cos(a);
    if (k <= .05) continue;
    final rect = Rect.fromCenter(
      center: Offset(math.sin(a) * math.cos(cr[1]) * r, math.sin(cr[1]) * r),
      width: cr[2] * r * k * 2,
      height: cr[2] * r * 2,
    );
    c.drawOval(rect, Paint()..color = const Color(0x5946496A));
    c.drawOval(
      rect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .015
        ..color = const Color(0x59FFFFFF),
    );
  }
  c.restore();
  _face(c, t, 0, 0, .9, 'sleepy', 200, const Color(0xFF231A4A));
}

void _comet(Canvas c, double t) {
  final a = t * .9;
  final hx = math.cos(a) * .22;
  final hy = math.sin(a * 1.3) * .16 - .1;
  for (var i = 24; i >= 0; i--) {
    final p = i / 24;
    _glow(
      c,
      hx - p * .75 + .05 * math.sin(t * 4 + i * .5) * p,
      hy + p * .55 + .04 * math.cos(t * 3 + i * .6) * p,
      .3 * (1 - p) + .05,
      _hsl(195 + p * 40, 95, 60, .35 * (1 - p) + .03),
      plus: true,
    );
  }
  c.save();
  c.translate(hx, hy);
  c.scale(.5);
  _star(c, t, h: 190, s: 95, l: 62, glow: false, eye: 'wide', faceColor: const Color(0xFF0E3A5A));
  c.restore();
}

void _pop(Canvas c, double t) {
  final h = 178 + 12 * math.sin(t * .8);
  final sway = math.sin(t * .6) * .1;
  _glow(c, 0, 0, .95, _hsl(h, 100, 60, .3));
  for (final sd in const [-1.0, 1.0]) {
    var px = sd * .22;
    var py = -.22;
    for (var i = 1; i <= 30; i++) {
      final p = i / 30;
      final x = sd * (.22 + p * .5 + .06 * math.sin(p * 6 - t * 2.6 + sd));
      final y = -.22 + p + .05 * math.sin(p * 8 - t * 3);
      c.drawLine(
        Offset(px, py),
        Offset(x, y),
        Paint()
          ..strokeCap = StrokeCap.round
          ..strokeWidth = .14 * (1 - p) + .012
          ..color = _hsl(h + p * 40, 100, 62, .65 * (1 - p) + .05)
          ..blendMode = BlendMode.plus,
      );
      px = x;
      py = y;
    }
  }
  for (final e in [
    [-.03, const Color(0x8C00D5FF)],
    [.03, const Color(0x73FF33C8)],
  ]) {
    c.save();
    c.translate(e[0] as double, 0);
    c.rotate(sway);
    c.drawPath(
      _starPath(5, .62, .31),
      Paint()
        ..color = e[1] as Color
        ..blendMode = BlendMode.plus,
    );
    c.restore();
  }
  _star(c, t, h: h, s: 95, l: 68, ro: .62, ri: .31, glow: false, withFace: false);
  _phones(c, t, h, .62, -.1);
  _face(c, t, 0, .04, 1, 'anime', h, const Color(0xFF0A3B4D));
  _spark(c, .5, -.5, .07 * (.6 + .4 * math.sin(t * 3)), Colors.white);
}

void _cat(Canvas c, double t) {
  const h = 285.0, s = 70.0, l = 72.0;
  _glow(c, 0, 0, .95, _hsl(h, s, l + 5, .2));
  final tail = Path()
    ..moveTo(.35, .4)
    ..cubicTo(.8, .45 + .1 * math.sin(t * 2), .85, -.05, .62, -.1 + .1 * math.sin(t * 2));
  c.drawPath(
    tail,
    Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = .1
      ..color = _hsl(h, s, l),
  );
  for (final sx in const [-1.0, 1.0]) {
    c.drawPath(
      Path()
        ..moveTo(sx * .12, -.42)
        ..lineTo(sx * .44, -.66)
        ..lineTo(sx * .4, -.28)
        ..close(),
      Paint()..color = _hsl(h, s, l - 6),
    );
    c.drawPath(
      Path()
        ..moveTo(sx * .2, -.42)
        ..lineTo(sx * .38, -.56)
        ..lineTo(sx * .36, -.34)
        ..close(),
      Paint()..color = const Color(0xFFFF9FC4),
    );
  }
  _star(c, t, h: h, s: s, l: l, glow: false, ro: .66, ri: .34, eye: 'cat');
  final w = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = .012
    ..color = const Color(0xD9FFFFFF);
  for (final sx in const [-1.0, 1.0]) {
    for (var i = 0; i < 3; i++) {
      c.drawLine(Offset(sx * .16, .1), Offset(sx * .5, .04 + i * .07), w);
    }
  }
  c.drawPath(
    Path()
      ..moveTo(-.035, .08)
      ..lineTo(.035, .08)
      ..lineTo(0, .12)
      ..close(),
    Paint()..color = const Color(0xFFFF6F9C),
  );
}

void _bee(Canvas c, double t) {
  _glow(c, 0, 0, .95, _hsl(50, 100, 60, .25));
  final fl = .7 + .3 * math.cos(t * 14).abs();
  for (final sx in const [-1.0, 1.0]) {
    c.save();
    c.translate(sx * .2, -.45);
    c.rotate(sx * (.5 + .2 * math.sin(t * 14)));
    c.drawOval(Rect.fromCenter(center: const Offset(0, -.14), width: 2 * (.12 * fl + .04), height: .48),
        Paint()..color = const Color(0xB3DCF0FF));
    c.restore();
  }
  _star(c, t, h: 48, s: 98, l: 60, glow: false, withFace: false);
  c.save();
  c.rotate(math.sin(t * .6) * .1);
  c.clipPath(_starPath(5, .7, .36));
  for (final y in const [-.42, .22, .44]) {
    c.drawRect(Rect.fromLTWH(-.8, y, 1.6, .1), Paint()..color = const Color(0xD928180A));
  }
  c.restore();
  _face(c, t, 0, .04, 1, 'happy', 200, const Color(0xFF231A4A));
}

// ---------- пузырьки ----------

void _soap(Canvas c, double t, [double hue = 200, String eye = 'happy']) {
  const r = .6;
  final k = .035 * math.sin(t * 2.1);
  c.save();
  c.scale(1 + k, 1 - k);
  _glow(c, 0, 0, .85, _hsl(hue, 90, 70, .12));
  c.drawCircle(
    Offset.zero,
    r,
    Paint()
      ..shader = ui.Gradient.radial(
        Offset.zero,
        r,
        const [Color(0x08FFFFFF), Color(0x47B4DCFF)],
        const [.2, 1.0],
      ),
  );
  c.drawCircle(
    Offset.zero,
    r,
    Paint()
      ..shader = ui.Gradient.sweep(
        Offset.zero,
        [
          _hsl(300, 100, 70, .22),
          _hsl(200, 100, 70, .22),
          _hsl(120, 100, 70, .22),
          _hsl(50, 100, 70, .22),
          _hsl(330, 100, 70, .22),
          _hsl(300, 100, 70, .22),
        ],
        const [0.0, .2, .4, .6, .8, 1.0],
        TileMode.clamp,
        -t * .4,
        -t * .4 + _tau,
      ),
  );
  _glass(c, t, r, hue);
  c.restore();
  _face(c, t, 0, .05, .9, eye, hue, _hsl(hue, 45, 38, .9));
}

void _drop(Canvas c, double t) {
  _glow(c, 0, .05, .9, _hsl(205, 95, 60, .25));
  final path = Path()
    ..moveTo(0, -.7)
    ..cubicTo(.12, -.45, .5, -.08, .5, .18)
    ..cubicTo(.5, .5, .27, .68, 0, .68)
    ..cubicTo(-.27, .68, -.5, .5, -.5, .18)
    ..cubicTo(-.5, -.08, -.12, -.45, 0, -.7)
    ..close();
  c.drawPath(
    path,
    Paint()
      ..shader = ui.Gradient.linear(
        const Offset(0, -.7),
        const Offset(0, .7),
        [_hsl(195, 100, 80, .85), _hsl(218, 90, 50, .9)],
      ),
  );
  c.save();
  c.clipPath(path);
  final wave = Path()..moveTo(-.6, .7);
  for (var x = -.6; x <= .6; x += .05) {
    wave.lineTo(x, .12 + .035 * math.sin(x * 9 + t * 3));
  }
  wave
    ..lineTo(.6, .7)
    ..close();
  c.drawPath(wave, Paint()..color = const Color(0x38FFFFFF));
  c.restore();
  c.drawPath(
    path,
    Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .03
      ..color = _hsl(195, 100, 88, .8),
  );
  c.save();
  c.translate(-.2, 0);
  c.rotate(.45);
  c.drawOval(Rect.fromCenter(center: Offset.zero, width: .14, height: .34),
      Paint()..color = const Color(0xA6FFFFFF));
  c.restore();
  _face(c, t, 0, .3, .9, 'anime', 210, const Color(0xFF12356B));
}

void _chorus(Canvas c, double t) {
  const r = .58;
  _glow(c, 0, 0, .95, _hsl(180, 100, 55, .3));
  c.save();
  c.clipPath(Path()..addOval(Rect.fromCircle(center: Offset.zero, radius: r)));
  c.drawRect(
    Rect.fromLTWH(-r, -r, r * 2, r * 2),
    Paint()
      ..shader = ui.Gradient.radial(
        Offset.zero,
        r,
        const [Color(0xFF0F4A63), Color(0xFF031A2B)],
      ),
  );
  for (var i = 0; i < 7; i++) {
    final hgt = .04 + .14 * (math.sin(t * 3.1 + i * .9) + .4 * math.sin(t * 5.3 + i)).abs();
    final x = -.33 + i * .11;
    c.drawLine(
      Offset(x, .24 - hgt),
      Offset(x, .24 + hgt),
      Paint()
        ..strokeCap = StrokeCap.round
        ..strokeWidth = .065
        ..shader = ui.Gradient.linear(
          Offset(0, .24 - hgt),
          Offset(0, .24 + hgt),
          const [Color(0xFF5FF3FF), Color(0xFFFF6AD5)],
        ),
    );
  }
  c.restore();
  _glass(c, t, r, 180);
  _phones(c, t, 175, r, 0);
  _face(c, t, 0, -.26, .9, 'anime', 175, const Color(0xFFD8FBFF));
}

void _galaxy(Canvas c, double t) {
  const r = .6;
  _glow(c, 0, 0, .95, _hsl(265, 90, 60, .3));
  c.save();
  c.clipPath(Path()..addOval(Rect.fromCircle(center: Offset.zero, radius: r)));
  c.drawRect(
    Rect.fromLTWH(-r, -r, r * 2, r * 2),
    Paint()
      ..shader = ui.Gradient.radial(
        const Offset(-.15, -.2),
        r * 1.3,
        const [Color(0xFF3A1A7A), Color(0xFF0B0620)],
      ),
  );
  for (var i = 0; i < 16; i++) {
    final a = i * 2.399 + t * .15;
    final d = (.1 + (i * 37 % 100) / 100 * .5);
    final p = Offset(math.cos(a) * d, math.sin(a) * d);
    final tw = .4 + .6 * (math.sin(t * 2 + i) * .5 + .5);
    c.drawCircle(p, .012 + .01 * (i % 3), Paint()..color = Colors.white.withValues(alpha: tw));
  }
  c.restore();
  _glass(c, t, r, 265);
  _face(c, t, 0, .02, .9, 'sleepy', 265, const Color(0xFFE9DEFF));
}
