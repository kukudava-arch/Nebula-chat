import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../intro/intro_screen.dart' show introShowing;
import '../main.dart' show navigatorKey;
import '../theme.dart';
import 'helper_models.dart';
import 'helper_service.dart';

const _starPhrases = [
  'Привет! Я рядом ✨',
  'Напиши кому-нибудь!',
  'Позвони другу — это легко.',
  'Космос сегодня тихий.',
  'Я умею ждать и светиться.',
];
const _bubblePhrases = [
  'Буль! Я тут.',
  'Не лопни от скуки!',
  'Хочешь поболтать?',
  'Лечу, куда ветер дует.',
  'Нажми на меня ещё!',
];

/// Накладывается поверх всех экранов: два помощника плавают и реагируют на касания.
class HelperOverlay extends StatefulWidget {
  final Widget child;
  const HelperOverlay({super.key, required this.child});

  @override
  State<HelperOverlay> createState() => _HelperOverlayState();
}

class _HelperOverlayState extends State<HelperOverlay> {
  @override
  void initState() {
    super.initState();
    HelperClock.I.start();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        widget.child,
        Positioned.fill(
          child: ValueListenableBuilder<bool>(
            valueListenable: introShowing,
            builder: (context, hide, _) => hide
                ? const SizedBox.shrink()
                : AnimatedBuilder(
            animation: HelperService.I,
            builder: (context, _) {
              final s = HelperService.I;
              return Stack(children: [
                if (s.starOn)
                  _Flyer(key: const ValueKey('star'), bubble: false, model: s.starModel, seed: 1),
                if (s.bubbleOn)
                  _Flyer(key: const ValueKey('bub'), bubble: true, model: s.bubbleModel, seed: 2),
              ]);
            },
          ),
          ),
        ),
      ],
    );
  }
}

class _Flyer extends StatefulWidget {
  final bool bubble;
  final String model;
  final int seed;
  const _Flyer({super.key, required this.bubble, required this.model, required this.seed});

  @override
  State<_Flyer> createState() => _FlyerState();
}

class _FlyerState extends State<_Flyer> {
  static const double sz = 92;
  Offset? anchor; // базовая точка, куда пользователь перетащил
  bool dragging = false;
  Offset dragPos = Offset.zero;
  String? phrase;
  int _phraseTick = 0;
  final _rnd = math.Random();

  void _say([String? text, int secs = 3]) {
    final list = widget.bubble ? _bubblePhrases : _starPhrases;
    final tick = ++_phraseTick;
    setState(() => phrase = text ?? list[_rnd.nextInt(list.length)]);
    Future.delayed(Duration(seconds: secs), () {
      if (mounted && tick == _phraseTick) setState(() => phrase = null);
    });
  }

  static const _advice = [
    'Выпей воды 💧',
    'Сделай маленькую паузу и посмотри вдаль.',
    'Напиши тому, о ком давно думал.',
    'Лучшее время начать — сейчас.',
    'Улыбнись, даже если никто не видит ✨',
  ];
  static const _compliments = [
    'У тебя классный вкус на звёзды!',
    'Ты светишься ярче туманности.',
    'С тобой этот космос уютнее.',
  ];
  static const _months = [
    'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
    'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря',
  ];

  /// Команды помощника. Всё считается на телефоне, без сервера.
  void _command(String id) {
    final now = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    switch (id) {
      case 'coin':
        _say(_rnd.nextBool() ? 'Орёл 🦅' : 'Решка 🪙', 4);
        break;
      case 'dice':
        _say('Кубик: ${1 + _rnd.nextInt(6)} 🎲', 4);
        break;
      case 'number':
        _say('Твоё число: ${1 + _rnd.nextInt(100)}', 4);
        break;
      case 'time':
        _say('${two(now.hour)}:${two(now.minute)}, ${now.day} ${_months[now.month - 1]}', 5);
        break;
      case 'ny':
        final ny = DateTime(now.year + 1, 1, 1);
        final days = ny.difference(DateTime(now.year, now.month, now.day)).inDays;
        _say('До Нового года: $days дн. 🎄', 5);
        break;
      case 'advice':
        _say(_advice[_rnd.nextInt(_advice.length)], 5);
        break;
      case 'compliment':
        _say(_compliments[_rnd.nextInt(_compliments.length)], 5);
        break;
      case 'timer':
        _say('Таймер на минуту запущен ⏱', 3);
        Future.delayed(const Duration(minutes: 1), () {
          if (mounted) _say('Минута прошла! ⏰', 6);
        });
        break;
      case 'hide':
        if (widget.bubble) {
          HelperService.I.setBubbleOn(false);
        } else {
          HelperService.I.setStarOn(false);
        }
        break;
      case 'model':
        _pick();
        break;
    }
  }

  void _menu() {
    final ctx = navigatorKey.currentContext;
    if (ctx == null) return;
    const cmds = <List<String>>[
      ['coin', '🪙 Орёл или решка'],
      ['dice', '🎲 Кубик'],
      ['number', '🔢 Число 1–100'],
      ['time', '🕒 Время и дата'],
      ['ny', '🎄 До Нового года'],
      ['advice', '💡 Совет'],
      ['compliment', '💜 Комплимент'],
      ['timer', '⏱ Таймер 1 мин'],
      ['model', '✨ Сменить модельку'],
      ['hide', '👋 Спрятать меня'],
    ];
    showModalBottomSheet<void>(
      context: ctx,
      backgroundColor: NebulaColors.surface,
      showDragHandle: true,
      builder: (sheet) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(widget.bubble ? 'Команды пузырька' : 'Команды звёздочки',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 14),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final c in cmds)
                ActionChip(
                  label: Text(c[1]),
                  onPressed: () {
                    Navigator.pop(sheet);
                    _command(c[0]);
                  },
                ),
            ]),
          ]),
        ),
      ),
    );
  }

  void _pick() {
    final ctx = navigatorKey.currentContext;
    if (ctx == null) return;
    showModalBottomSheet(
      context: ctx,
      backgroundColor: NebulaColors.surface,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) => _PickerSheet(bubble: widget.bubble),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final pad = MediaQuery.of(context).padding;
    final minX = 4.0, maxX = size.width - sz - 4;
    final minY = pad.top + 4, maxY = size.height - sz - pad.bottom - 80;
    anchor ??= widget.bubble
        ? Offset(maxX - 10, maxY * .62)
        : Offset(maxX - 10, maxY * .38);
    return ValueListenableBuilder<double>(
      valueListenable: HelperClock.I,
      builder: (context, t, _) {
        final k = widget.seed * 1.7;
        var pos = dragging
            ? dragPos
            : anchor! + Offset(math.sin(t * .45 + k) * 14, math.cos(t * .6 + k * 2) * 18);
        pos = Offset(pos.dx.clamp(minX, maxX).toDouble(), pos.dy.clamp(minY, maxY).toDouble());
        final left = pos.dx > size.width / 2;
        return Positioned(
          left: pos.dx,
          top: pos.dy,
          width: sz,
          height: sz,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(
                left: sz * .2,
                right: sz * .2,
                bottom: -2,
                height: 9,
                child: IgnorePointer(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: .35),
                          blurRadius: 10,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _say(),
                onLongPress: _menu,
                onPanStart: (_) => setState(() {
                  dragging = true;
                  dragPos = pos;
                }),
                onPanUpdate: (d) => setState(() => dragPos += d.delta),
                onPanEnd: (_) => setState(() {
                  dragging = false;
                  anchor = Offset(dragPos.dx.clamp(minX, maxX).toDouble(),
                      dragPos.dy.clamp(minY, maxY).toDouble());
                }),
                child: AnimatedScale(
                  scale: dragging ? 1.15 : 1,
                  duration: const Duration(milliseconds: 200),
                  child: CustomPaint(
                    size: const Size(sz, sz),
                    painter: HelperPainter(widget.model, t + widget.seed * 3),
                  ),
                ),
              ),
              if (phrase != null)
                Positioned(
                  bottom: sz + 4,
                  right: left ? 0 : null,
                  left: left ? null : 0,
                  child: IgnorePointer(
                    child: Material(
                      type: MaterialType.transparency,
                      child: Container(
                      constraints: const BoxConstraints(maxWidth: 190),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: NebulaColors.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: NebulaColors.accent.withValues(alpha: .5)),
                      ),
                      child: Text(phrase!, style: const TextStyle(fontSize: 13)),
                    ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _PickerSheet extends StatelessWidget {
  final bool bubble;
  const _PickerSheet({required this.bubble});

  @override
  Widget build(BuildContext context) {
    final models = kHelperModels.where((m) => m.bubble == bubble).toList();
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: AnimatedBuilder(
          animation: HelperService.I,
          builder: (context, _) {
            final cur = bubble ? HelperService.I.bubbleModel : HelperService.I.starModel;
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(bubble ? 'Выбери пузырёк' : 'Выбери звёздочку',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 14),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    for (final m in models)
                      GestureDetector(
                        onTap: () => HelperService.I.setModel(m),
                        child: Container(
                          width: 96,
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: m.id == cur ? NebulaColors.accent : Colors.white12,
                              width: m.id == cur ? 2 : 1,
                            ),
                          ),
                          child: Column(children: [
                            ValueListenableBuilder<double>(
                              valueListenable: HelperClock.I,
                              builder: (_, t, __) => CustomPaint(
                                size: const Size(64, 64),
                                painter: HelperPainter(m.id, t),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(m.name,
                                textAlign: TextAlign.center,
                                style: const TextStyle(fontSize: 11)),
                          ]),
                        ),
                      ),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
