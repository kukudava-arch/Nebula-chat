import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import 'notify.dart';

/// Адрес сервера по умолчанию. Можно вписать свой, например 'http://192.168.0.10:3000'.
/// Пользователь всё равно может изменить его на экране входа.
const String kDefaultServer = '';

/// Кому писать для оплаты премиума (логин администратора).
const String kAdminContact = 'davtroadmin1';

class ChatMessage {
  final String id, from, to, text;
  final int ts;
  ChatMessage({
    required this.id,
    required this.from,
    required this.to,
    required this.text,
    required this.ts,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> j) => ChatMessage(
        id: j['id'] as String,
        from: j['from'] as String,
        to: j['to'] as String,
        text: j['text'] as String,
        ts: (j['ts'] as num).toInt(),
      );
}

class ChatPreview {
  final String user, displayName, text, from;
  final int ts;
  ChatPreview({
    required this.user,
    required this.displayName,
    required this.text,
    required this.from,
    required this.ts,
  });

  factory ChatPreview.fromJson(Map<String, dynamic> j) {
    AppState.I.putLook(j['user'] as String, j['look']);
    return ChatPreview._from(j);
  }

  factory ChatPreview._from(Map<String, dynamic> j) => ChatPreview(
        user: j['user'] as String,
        displayName: j['displayName'] as String,
        text: j['text'] as String,
        from: j['from'] as String,
        ts: (j['ts'] as num).toInt(),
      );
}

class UserInfo {
  final String username, displayName;
  UserInfo({required this.username, required this.displayName});

  factory UserInfo.fromJson(Map<String, dynamic> j) {
    AppState.I.putLook(j['username'] as String, j['look']);
    return UserInfo(
      username: j['username'] as String,
      displayName: j['displayName'] as String,
    );
  }
}

/// Внешний вид пользователя: аватар «эмодзи|оттенок», цвет ника, премиум.
class Look {
  final String avatar, nickColor;
  final bool premium;
  const Look({this.avatar = '', this.nickColor = '', this.premium = false});

  factory Look.fromJson(dynamic j) {
    if (j is! Map) return const Look();
    return Look(
      avatar: (j['a'] as String?) ?? '',
      nickColor: (j['c'] as String?) ?? '',
      premium: j['p'] == true,
    );
  }
}

class Story {
  final String id, user, name, text;
  final int bg, ts;
  Story({
    required this.id,
    required this.user,
    required this.name,
    required this.text,
    required this.bg,
    required this.ts,
  });

  factory Story.fromJson(Map<String, dynamic> j) {
    AppState.I.putLook(j['user'] as String, j['look']);
    return Story(
      id: j['id'] as String,
      user: j['user'] as String,
      name: j['name'] as String,
      text: j['text'] as String,
      bg: (j['bg'] as num).toInt(),
      ts: (j['ts'] as num).toInt(),
    );
  }
}

class AdminUser {
  final String username, displayName;
  final bool premium, admin, online;
  AdminUser({
    required this.username,
    required this.displayName,
    required this.premium,
    required this.admin,
    required this.online,
  });

  factory AdminUser.fromJson(Map<String, dynamic> j) => AdminUser(
        username: j['username'] as String,
        displayName: j['displayName'] as String,
        premium: j['premium'] == true,
        admin: j['admin'] == true,
        online: j['online'] == true,
      );
}

class CallRecord {
  final String peer, peerName;
  final bool video, incoming, answered;
  final int ts, durationSec;
  CallRecord({
    required this.peer,
    required this.peerName,
    required this.video,
    required this.incoming,
    required this.answered,
    required this.ts,
    required this.durationSec,
  });

  Map<String, dynamic> toJson() => {
        'peer': peer,
        'peerName': peerName,
        'video': video,
        'incoming': incoming,
        'answered': answered,
        'ts': ts,
        'durationSec': durationSec,
      };

  factory CallRecord.fromJson(Map<String, dynamic> j) => CallRecord(
        peer: j['peer'] as String,
        peerName: j['peerName'] as String,
        video: j['video'] as bool,
        incoming: j['incoming'] as bool,
        answered: j['answered'] as bool,
        ts: (j['ts'] as num).toInt(),
        durationSec: (j['durationSec'] as num).toInt(),
      );
}

/// Всё состояние приложения: сессия, соединение с сервером, чаты, история звонков.
class AppState extends ChangeNotifier {
  AppState._();
  static final AppState I = AppState._();

  final ValueNotifier<bool> loggedIn = ValueNotifier<bool>(false);
  late SharedPreferences _prefs;

  String serverUrl = '';
  String token = '';
  String username = '';
  String displayName = '';
  bool connected = false;
  bool demo = false; // показ интерфейса без сервера
  bool premium = false;
  bool admin = false;
  String intro = 'eye'; // стиль заставки при входе
  List<AdminUser> adminUsers = [];
  int adminTotal = 0;
  String _adminQuery = '';
  final Set<String> _demoPremium = {};
  final Map<String, Look> looks = {};
  List<Story> stories = [];

  void putLook(String user, dynamic j) {
    if (j != null) looks[user] = Look.fromJson(j);
  }

  Look lookOf(String user) => looks[user] ?? const Look();

  List<ChatPreview> chats = [];
  final Map<String, List<ChatMessage>> messages = {};
  final Set<String> freshIds = {}; // сообщения, пришедшие «вживую» (для анимации)
  List<UserInfo> searchResults = [];
  bool searching = false;
  List<CallRecord> calls = [];

  WebSocketChannel? _ch;
  StreamSubscription? _sub;
  Timer? _reconnect;
  int _attempt = 0;
  bool _wantConnection = false;

  final StreamController<Map<String, dynamic>> _signals =
      StreamController<Map<String, dynamic>>.broadcast();
  Stream<Map<String, dynamic>> get signals => _signals.stream;

  final StreamController<String> _errors = StreamController<String>.broadcast();
  Stream<String> get errors => _errors.stream;
  void pushError(String text) => _errors.add(text);

  // ---------- запуск ----------
  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    final override = _prefs.getString('server_override') ?? '';
    serverUrl = override.isNotEmpty ? override : kDefaultServer;
    premium = _prefs.getBool('premium') ?? false;
    admin = _prefs.getBool('admin') ?? false;
    intro = _prefs.getString('intro') ?? 'eye';
    token = _prefs.getString('token') ?? '';
    username = _prefs.getString('username') ?? '';
    displayName = _prefs.getString('displayName') ?? '';

    final raw = _prefs.getString('calls');
    if (raw != null) {
      try {
        calls = (jsonDecode(raw) as List)
            .map((e) => CallRecord.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {
        calls = [];
      }
    }

    if (token.isNotEmpty && serverUrl.isNotEmpty) {
      loggedIn.value = true;
      _connect();
    }
  }

  static String normalizeServer(String s) {
    var v = s.trim();
    if (v.isEmpty) return '';
    if (!v.startsWith('http://') && !v.startsWith('https://')) v = 'http://$v';
    while (v.endsWith('/')) {
      v = v.substring(0, v.length - 1);
    }
    return v;
  }

  // ---------- вход / регистрация ----------
  /// Возвращает текст ошибки или null при успехе.
  Future<String?> authenticate({
    required bool register,
    String? server,
    required String user,
    required String password,
    String name = '',
  }) async {
    final base = normalizeServer(server ?? serverUrl);
    if (base.isEmpty) {
      return 'Сервер ещё не подключён. Пока можно только посмотреть демо.';
    }
    if (user.trim().isEmpty || password.isEmpty) return 'Введите логин и пароль';
    try {
      final endpoint = register ? 'register' : 'login';
      final res = await http
          .post(
            Uri.parse('$base/api/$endpoint'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'username': user.trim(),
              'password': password,
              if (register) 'displayName': name.trim(),
            }),
          )
          .timeout(const Duration(seconds: 12));
      final data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      if (res.statusCode != 200) {
        return (data['error'] as String?) ?? 'Ошибка ${res.statusCode}';
      }
      serverUrl = base;
      token = data['token'] as String;
      _applyProfile(data);
      await _prefs.setString('token', token);
      loggedIn.value = true;
      _connect();
      notifyListeners();
      return null;
    } on TimeoutException {
      return 'Сервер не отвечает. Проверьте адрес.';
    } catch (_) {
      return 'Не удалось подключиться к серверу';
    }
  }

  Future<void> logout() async {
    demo = false;
    _wantConnection = false;
    _reconnect?.cancel();
    _closeChannel();
    connected = false;
    token = '';
    username = '';
    displayName = '';
    chats = [];
    messages.clear();
    freshIds.clear();
    searchResults = [];
    calls = [];
    premium = false;
    admin = false;
    intro = 'eye';
    adminUsers = [];
    await _prefs.remove('premium');
    await _prefs.remove('admin');
    await _prefs.remove('intro');
    await _prefs.remove('token');
    await _prefs.remove('username');
    await _prefs.remove('displayName');
    await _prefs.remove('calls');
    loggedIn.value = false;
    notifyListeners();
  }

  // ---------- соединение ----------
  void _connect() {
    _wantConnection = true;
    _reconnect?.cancel();
    _closeChannel();

    try {
      final base = Uri.parse(serverUrl);
      final uri = Uri(
        scheme: base.scheme == 'https' ? 'wss' : 'ws',
        host: base.host,
        port: base.hasPort ? base.port : null,
        path: '/ws',
        queryParameters: {'token': token},
      );
      final ch = IOWebSocketChannel.connect(
        uri,
        pingInterval: const Duration(seconds: 20),
      );
      _ch = ch;
      ch.ready.catchError((Object e) {
        if (_ch != ch) return;
        if (e.toString().contains('401')) {
          pushError('Сессия истекла, войдите снова');
          logout();
        }
      });
      _sub = ch.stream.listen(
        _onData,
        onDone: () => _onClosed(ch),
        onError: (Object _) => _onClosed(ch),
        cancelOnError: true,
      );
    } catch (_) {
      _scheduleReconnect();
    }
  }

  void _closeChannel() {
    _sub?.cancel();
    _sub = null;
    try {
      _ch?.sink.close();
    } catch (_) {}
    _ch = null;
  }

  void _onClosed(WebSocketChannel ch) {
    if (_ch != ch) return;
    connected = false;
    notifyListeners();
    if (_wantConnection) _scheduleReconnect();
  }

  void _scheduleReconnect() {
    _reconnect?.cancel();
    final secs = math.min(30, 1 << math.min(_attempt, 5));
    _attempt++;
    _reconnect = Timer(Duration(seconds: secs), () {
      if (_wantConnection) _connect();
    });
  }

  /// Вызывается при возврате приложения на передний план.
  void ensureConnected() {
    if (_wantConnection && !connected) {
      _attempt = 0;
      _connect();
    }
  }

  void _send(Map<String, dynamic> m) {
    try {
      _ch?.sink.add(jsonEncode(m));
    } catch (_) {}
  }

  void _onData(dynamic raw) {
    Map<String, dynamic> m;
    try {
      m = jsonDecode(raw as String) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final type = m['type'] as String?;
    switch (type) {
      case 'stories':
        stories = (m['stories'] as List)
            .map((e) => Story.fromJson(e as Map<String, dynamic>))
            .toList();
        notifyListeners();
        break;
      case 'password_changed':
        pushError('Пароль изменён');
        break;
      case 'profile':
        _applyProfile(m);
        notifyListeners();
        break;
      case 'admin_users':
        adminUsers = (m['users'] as List)
            .map((e) => AdminUser.fromJson(e as Map<String, dynamic>))
            .toList();
        adminTotal = (m['total'] as num?)?.toInt() ?? adminUsers.length;
        notifyListeners();
        break;
      case 'admin_done':
        adminLoad(_adminQuery);
        break;
      case 'hello':
        _applyProfile(m);
        connected = true;
        loadStories();
        _attempt = 0;
        requestChats();
        notifyListeners();
        break;
      case 'chats':
        chats = (m['chats'] as List)
            .map((e) => ChatPreview.fromJson(e as Map<String, dynamic>))
            .toList();
        notifyListeners();
        break;
      case 'history':
        final w = m['with'] as String;
        messages[w] = (m['messages'] as List)
            .map((e) => ChatMessage.fromJson(e as Map<String, dynamic>))
            .toList();
        notifyListeners();
        break;
      case 'message':
        final msg = ChatMessage.fromJson(m['msg'] as Map<String, dynamic>);
        final other = msg.from == username ? msg.to : msg.from;
        final list = messages.putIfAbsent(other, () => []);
        if (!list.any((x) => x.id == msg.id)) {
          list.add(msg);
          freshIds.add(msg.id);
          if (msg.from != username && !Notify.I.foreground) {
            Notify.I.showMessage((m['fromName'] as String?) ?? msg.from, msg.text);
          }
        }
        requestChats();
        notifyListeners();
        break;
      case 'search':
        searchResults = (m['users'] as List)
            .map((e) => UserInfo.fromJson(e as Map<String, dynamic>))
            .toList();
        searching = false;
        notifyListeners();
        break;
      case 'error':
        pushError((m['error'] as String?) ?? 'Ошибка');
        break;
      default:
        if (type != null && type.startsWith('call_')) _signals.add(m);
    }
  }

  // ---------- действия ----------
  void requestChats() {
    if (demo) return;
    _send({'type': 'chats'});
  }

  void loadHistory(String peer) {
    if (demo) return;
    _send({'type': 'history', 'with': peer});
  }

  void search(String q) {
    if (demo) {
      final t = q.trim().toLowerCase();
      searchResults = t.length < 2
          ? []
          : _demoUsers
              .where((u) => u.username.contains(t) || u.displayName.toLowerCase().contains(t))
              .toList();
      searching = false;
      notifyListeners();
      return;
    }
    searching = q.trim().length >= 2;
    _send({'type': 'search', 'q': q});
    notifyListeners();
  }

  void clearSearch({bool notify = true}) {
    searchResults = [];
    searching = false;
    if (notify) notifyListeners();
  }

  void sendMessage(String to, String text) {
    if (demo) {
      _demoSend(to, text);
      return;
    }
    if (!connected) {
      pushError('Нет соединения с сервером');
      return;
    }
    _send({'type': 'send', 'to': to, 'text': text});
  }

  void sendSignal(Map<String, dynamic> m) => _send(m);

  Future<void> addCall(CallRecord r) async {
    calls.insert(0, r);
    if (calls.length > 100) calls = calls.sublist(0, 100);
    await _prefs.setString('calls', jsonEncode(calls.map((c) => c.toJson()).toList()));
    notifyListeners();
  }


  // ---------- профиль, премиум, админ ----------
  void _applyProfile(Map<String, dynamic> m) {
    username = (m['username'] as String?) ?? username;
    displayName = (m['displayName'] as String?) ?? displayName;
    premium = m['premium'] == true;
    admin = m['admin'] == true;
    intro = (m['intro'] as String?) ?? 'eye';
    putLook(username, m['look']);
    _prefs.setString('username', username);
    _prefs.setString('displayName', displayName);
    _prefs.setBool('premium', premium);
    _prefs.setBool('admin', admin);
    _prefs.setString('intro', intro);
  }

  Future<void> setServerOverride(String value) async {
    final v = normalizeServer(value);
    await _prefs.setString('server_override', v);
    serverUrl = v.isNotEmpty ? v : kDefaultServer;
    notifyListeners();
  }

  void setIntro(String style) {
    if (demo) {
      intro = style;
      notifyListeners();
      return;
    }
    _send({'type': 'set_intro', 'style': style});
  }

  void adminLoad(String q) {
    _adminQuery = q;
    if (demo) {
      final t = q.trim().toLowerCase();
      final all = [
        ..._demoUsers.map((u) => (u.username, u.displayName)),
        (username, displayName),
      ];
      adminUsers = [
        for (final e in all)
          if (t.isEmpty || e.$1.contains(t) || e.$2.toLowerCase().contains(t))
            AdminUser(
              username: e.$1,
              displayName: e.$2,
              premium: _demoPremium.contains(e.$1),
              admin: e.$1 == username,
              online: e.$1 != 'vega',
            ),
      ];
      adminTotal = adminUsers.length;
      notifyListeners();
      return;
    }
    _send({'type': 'admin_users', 'q': q});
  }

  void adminSetPremium(String user, bool value) {
    if (demo) {
      value ? _demoPremium.add(user) : _demoPremium.remove(user);
      if (user == username) premium = value;
      adminLoad(_adminQuery);
      return;
    }
    _send({'type': 'admin_premium', 'user': user, 'premium': value});
  }


  // ---------- профиль и истории ----------
  void updateProfile({String? displayName, String? avatar, String? nickColor}) {
    if (demo) {
      if (displayName != null && displayName.trim().isNotEmpty) this.displayName = displayName.trim();
      if (avatar != null || nickColor != null) {
        final old = lookOf(username);
        looks[username] = Look(
          avatar: avatar ?? old.avatar,
          nickColor: nickColor ?? old.nickColor,
          premium: premium,
        );
      }
      notifyListeners();
      return;
    }
    _send({
      'type': 'update_profile',
      if (displayName != null) 'displayName': displayName,
      if (avatar != null) 'avatar': avatar,
      if (nickColor != null) 'nickColor': nickColor,
    });
  }

  void changePassword(String oldPw, String newPw) {
    if (demo) {
      pushError('В демо-режиме пароль не меняется');
      return;
    }
    _send({'type': 'change_password', 'old': oldPw, 'new': newPw});
  }

  void loadStories() {
    if (demo) return;
    _send({'type': 'stories'});
  }

  void postStory(String text, int bg) {
    if (demo) {
      if (!premium) {
        pushError('Истории доступны с премиумом');
        return;
      }
      stories.add(Story(
        id: 'ds${DateTime.now().millisecondsSinceEpoch}',
        user: username,
        name: displayName,
        text: text,
        bg: bg,
        ts: DateTime.now().millisecondsSinceEpoch,
      ));
      notifyListeners();
      return;
    }
    _send({'type': 'story_post', 'text': text, 'bg': bg});
  }

  void deleteStory(String id) {
    if (demo) {
      stories.removeWhere((x) => x.id == id);
      notifyListeners();
      return;
    }
    _send({'type': 'story_delete', 'id': id});
  }

  // ---------- демо-режим: посмотреть интерфейс без сервера ----------
  static final List<UserInfo> _demoUsers = [
    UserInfo(username: 'luna', displayName: 'Луна'),
    UserInfo(username: 'orion', displayName: 'Орион'),
    UserInfo(username: 'mama', displayName: 'Мама'),
    UserInfo(username: 'vega', displayName: 'Вега'),
  ];

  void enterDemo() {
    demo = true;
    connected = true;
    username = 'demo';
    displayName = 'Гость';
    admin = true;
    premium = false;
    serverUrl = 'демо (без сервера)';
    final now = DateTime.now().millisecondsSinceEpoch;
    ChatMessage m(String id, String from, String to, String text, int minAgo) => ChatMessage(
          id: id,
          from: from,
          to: to,
          text: text,
          ts: now - minAgo * 60000,
        );
    messages.clear();
    messages['luna'] = [
      m('d1', 'luna', 'demo', 'Привет! Видела новую звёздочку?', 42),
      m('d2', 'demo', 'luna', 'Да! Она летает по всему экрану', 40),
      m('d3', 'luna', 'demo', 'Скоро Новый год, соберёмся в звонке?', 12),
    ];
    messages['orion'] = [
      m('d4', 'demo', 'orion', 'Ты где?', 300),
      m('d5', 'orion', 'demo', 'Летаю в космосе', 280),
    ];
    messages['mama'] = [
      m('d6', 'mama', 'demo', 'Не забудь позвонить вечером', 1500),
    ];
    chats = [
      for (final e in [
        ['luna', 'Луна'],
        ['orion', 'Орион'],
        ['mama', 'Мама'],
      ])
        ChatPreview(
          user: e[0],
          displayName: e[1],
          text: messages[e[0]]!.last.text,
          from: messages[e[0]]!.last.from,
          ts: messages[e[0]]!.last.ts,
        ),
    ];
    calls = [
      CallRecord(
          peer: 'luna', peerName: 'Луна', video: true, incoming: false, answered: true,
          ts: now - 3600000, durationSec: 312),
      CallRecord(
          peer: 'mama', peerName: 'Мама', video: false, incoming: true, answered: false,
          ts: now - 7200000, durationSec: 0),
      CallRecord(
          peer: 'orion', peerName: 'Орион', video: false, incoming: true, answered: true,
          ts: now - 86400000, durationSec: 95),
    ];
    final t0 = DateTime.now().millisecondsSinceEpoch;
    stories = [
      Story(id: 'd1', user: 'luna', name: 'Луна', text: 'Скоро Новый год! ✨', bg: 2, ts: t0 - 3600000),
      Story(id: 'd2', user: 'orion', name: 'Орион', text: 'Летаю в космосе', bg: 5, ts: t0 - 7200000),
    ];
    looks['luna'] = const Look(avatar: '🦊|210', nickColor: '#FF7AC8', premium: true);
    looks['orion'] = const Look(avatar: '🚀|150', premium: false);
    looks['mama'] = const Look(avatar: '🌸|330', premium: false);
    loggedIn.value = true;
    notifyListeners();
  }

  void _demoSend(String to, String text) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final mine = ChatMessage(id: 'dm$now', from: username, to: to, text: text, ts: now);
    messages.putIfAbsent(to, () => []).add(mine);
    freshIds.add(mine.id);
    _demoBump(to, mine);
    notifyListeners();
    Future.delayed(const Duration(milliseconds: 1400), () {
      if (!demo) return;
      final t = DateTime.now().millisecondsSinceEpoch;
      final reply = ChatMessage(
          id: 'dr$t', from: to, to: username, text: 'Это демо-ответ ✨', ts: t);
      messages.putIfAbsent(to, () => []).add(reply);
      freshIds.add(reply.id);
      _demoBump(to, reply);
      notifyListeners();
    });
  }

  void _demoBump(String peer, ChatMessage msg) {
    final name = _demoUsers
        .firstWhere((u) => u.username == peer,
            orElse: () => UserInfo(username: peer, displayName: peer))
        .displayName;
    chats.removeWhere((c) => c.user == peer);
    chats.insert(
        0,
        ChatPreview(
            user: peer, displayName: name, text: msg.text, from: msg.from, ts: msg.ts));
  }
}
