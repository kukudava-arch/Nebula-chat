import 'dart:io' show Platform;
import 'dart:typed_data' show Int64List;

import 'package:flutter/widgets.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Точка входа фоновой службы. Службе делать нечего: она просто держит
/// процесс приложения живым, чтобы WebSocket продолжал принимать сообщения и звонки.
@pragma('vm:entry-point')
void nebulaServiceCallback() {
  FlutterForegroundTask.setTaskHandler(_IdleHandler());
}

class _IdleHandler extends TaskHandler {
  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {}

  @override
  void onRepeatEvent(DateTime timestamp) {}

  @override
  Future<void> onDestroy(DateTime timestamp, bool isTimeout) async {}
}

/// Уведомления о сообщениях, входящие звонки и фоновая служба.
class Notify with WidgetsBindingObserver {
  Notify._();
  static final Notify I = Notify._();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool foreground = true;
  bool _ready = false;
  int _msgId = 1000;

  Future<void> init() async {
    if (!Platform.isAndroid) return;
    try {
      FlutterForegroundTask.initCommunicationPort();
      await _plugin.initialize(
        const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher'),
        ),
      );
      FlutterForegroundTask.init(
        androidNotificationOptions: AndroidNotificationOptions(
          channelId: 'nebula_service',
          channelName: 'Фоновая работа',
          channelDescription: 'Нужна, чтобы приходили сообщения и звонки',
          onlyAlertOnce: true,
        ),
        iosNotificationOptions: const IOSNotificationOptions(
          showNotification: false,
          playSound: false,
        ),
        foregroundTaskOptions: ForegroundTaskOptions(
          eventAction: ForegroundTaskEventAction.nothing(),
          autoRunOnBoot: false,
          allowWakeLock: true,
          allowWifiLock: true,
        ),
      );
      WidgetsBinding.instance.addObserver(this);
      _ready = true;
    } catch (e) {
      debugPrint('Notify.init: $e');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    foreground = state == AppLifecycleState.resumed;
  }

  Future<void> askPermissions() async {
    if (!_ready) return;
    try {
      final perm = await FlutterForegroundTask.checkNotificationPermission();
      if (perm != NotificationPermission.granted) {
        await FlutterForegroundTask.requestNotificationPermission();
      }
      if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
        await FlutterForegroundTask.requestIgnoreBatteryOptimization();
      }
      await _plugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.requestFullScreenIntentPermission();
    } catch (e) {
      debugPrint('Notify.askPermissions: $e');
    }
  }

  Future<void> startService() async {
    if (!_ready) return;
    try {
      if (await FlutterForegroundTask.isRunningService) return;
      await FlutterForegroundTask.startService(
        serviceId: 256,
        notificationTitle: 'Nebula Chat',
        notificationText: 'На связи: сообщения и звонки',
        callback: nebulaServiceCallback,
      );
    } catch (e) {
      debugPrint('Notify.startService: $e');
    }
  }

  Future<void> stopService() async {
    if (!_ready) return;
    try {
      if (await FlutterForegroundTask.isRunningService) {
        await FlutterForegroundTask.stopService();
      }
    } catch (e) {
      debugPrint('Notify.stopService: $e');
    }
  }

  Future<void> showMessage(String from, String text) async {
    if (!_ready) return;
    try {
      await _plugin.show(
        _msgId++,
        from,
        text,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'nebula_messages',
            'Сообщения',
            channelDescription: 'Новые сообщения',
            importance: Importance.high,
            priority: Priority.high,
            category: AndroidNotificationCategory.message,
          ),
        ),
      );
      if (_msgId > 1900) _msgId = 1000;
    } catch (e) {
      debugPrint('Notify.showMessage: $e');
    }
  }

  static const int _callId = 777;

  Future<void> showIncomingCall(String from, bool video) async {
    if (!_ready || foreground) return;
    try {
      await _plugin.show(
        _callId,
        from,
        video ? 'Входящий видеозвонок' : 'Входящий звонок',
        NotificationDetails(
          android: AndroidNotificationDetails(
            'nebula_calls',
            'Звонки',
            channelDescription: 'Входящие звонки',
            importance: Importance.max,
            priority: Priority.max,
            category: AndroidNotificationCategory.call,
            fullScreenIntent: true,
            ongoing: true,
            autoCancel: false,
            timeoutAfter: 50000,
            playSound: true,
            enableVibration: true,
            vibrationPattern: Int64List.fromList(const [0, 600, 400, 600, 400, 600]),
          ),
        ),
      );
    } catch (e) {
      debugPrint('Notify.showIncomingCall: $e');
    }
  }

  Future<void> cancelCall() async {
    if (!_ready) return;
    try {
      await _plugin.cancel(_callId);
    } catch (_) {}
  }
}
