import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../theme.dart';

/// Пока идёт заставка, летающие помощники прячутся.
final ValueNotifier<bool> introShowing = ValueNotifier<bool>(false);

class IntroStyle {
  final String id, name, note;
  const IntroStyle(this.id, this.name, this.note);
}

const List<IntroStyle> kIntroStyles = [
  IntroStyle('eye', 'Глаз', 'Серо-голубой глаз, зум в зрачок и космос внутри'),
  IntroStyle('nebula', 'Туманность', 'Вихрь частиц собирается в светящееся ядро'),
  IntroStyle('burst', 'Звёздный взрыв', 'Звезда вспыхивает и рассыпается искрами'),
];

double _clamp01(double x) => x < 0 ? 0 : (x > 1 ? 1 : x);
double _seg(double t, double a, double b) => _clamp01((t - a) / (b - a));
double _ease(double x) => x * x * (3 - 2 * x);
double _easeIn(double x) => x * x * x;

Color _hsl(double h, double s, double l, [double a = 1]) => HSLColor.fromAHSL(
      _clamp01(a),
      ((h % 360) + 360) % 360,
      _clamp01(s / 100),
      _clamp01(l / 100),
    ).toColor();

/// Заставка при входе в приложение. [style] — eye / nebula / burst.
class IntroScreen extends StatefulWidget {
  final String style;
  final VoidCallback onDone;
  const IntroScreen({super.key, required this.style, required this.onDone});

  @override
  State<IntroScreen> createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => introShowing.value = true);
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 5600))
      ..addStatusListener((s) {
        if (s == AnimationStatus.completed) _finish();
      })
      ..forward();
  }

  void _finish() {
    if (_done) return;
    _done = true;
    widget.onDone();
  }

  @override
  void dispose() {
    _c.dispose();
    introShowing.value = false;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _finish,
      child: Scaffold(
        backgroundColor: const Color(0xFF05060F),
        body: AnimatedBuilder(
          animation: _c,
          builder: (context, _) {
            final t = _c.value;
            final titleA = _ease(_seg(t, .74, .9));
            return Stack(
              fit: StackFit.expand,
              children: [
                CustomPaint(painter: _IntroPainter(widget.style, t, _c.value * 5.6)),
                Align(
                  alignment: const Alignment(0, .62),
                  child: Opacity(
                    opacity: titleA,
                    child: Transform.translate(
                      offset: Offset(0, (1 - titleA) * 14),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ShaderMask(
                            shaderCallback: (r) => NebulaColors.gradient.createShader(r),
                            child: const Text(
                              'Nebula',
                              style: TextStyle(
                                fontSize: 46,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 2,
                                color: Colors.white,
                              ),
                            ),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'Чаты, звонки и сделки в одном месте',
                            style: TextStyle(color: NebulaColors.textDim, fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Positioned(
                  right: 18,
                  bottom: 18 + MediaQuery.of(context).padding.bottom,
                  child: Opacity(
                    opacity: .4,
                    child: const Text('нажми, чтобы пропустить',
                        style: TextStyle(color: Colors.white, fontSize: 11)),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _IntroPainter extends CustomPainter {
  final String style;
  final double t; // 0..1
  final double sec; // секунды
  _IntroPainter(this.style, this.t, this.sec);

  @override
  void paint(Canvas canvas, Size size) {
    switch (style) {
      case 'nebula':
        _nebula(canvas, size);
        break;
      case 'burst':
        _burst(canvas, size);
        break;
      default:
        _eye(canvas, size);
    }
  }

  @override
  bool shouldRepaint(_IntroPainter old) => old.t != t || old.style != style;

  // ---------- общий космос: звёзды и туманность-сердце ----------
  void _space(Canvas c, Size s, double amount) {
    final r = Offset.zero & s;
    c.drawRect(
      r,
      Paint()
        ..shader = ui.Gradient.radial(
          s.center(Offset.zero),
          s.longestSide * .7,
          [const Color(0xFF14123A), const Color(0xFF04050C)],
        ),
    );
    // туманность в форме сердца
    final cx = s.width / 2, cy = s.height * .46;
    final k = s.width * .16 * (.9 + .1 * math.sin(sec * 2.4)) * amount;
    final heart = Path()
      ..moveTo(cx, cy + k * 1.15)
      ..cubicTo(cx - k * 2.2, cy - k * .1, cx - k * 1.0, cy - k * 1.7, cx, cy - k * .55)
      ..cubicTo(cx + k * 1.0, cy - k * 1.7, cx + k * 2.2, cy - k * .1, cx, cy + k * 1.15)
      ..close();
    c.drawPath(
      heart,
      Paint()
        ..color = const Color(0xFFFF4D9A).withValues(alpha: .55 * amount)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, k * .55),
    );
    c.drawPath(
      heart,
      Paint()
        ..color = const Color(0xFF7C5CFF).withValues(alpha: .35 * amount)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, k * 1.1),
    );
    // звёзды
    final rnd = math.Random(7);
    for (var i = 0; i < 90; i++) {
      final x = rnd.nextDouble() * s.width;
      final y = rnd.nextDouble() * s.height;
      final base = .25 + rnd.nextDouble() * .75;
      final tw = .55 + .45 * math.sin(sec * (1 + rnd.nextDouble() * 2.5) + i);
      final a = base * tw * amount;
      c.drawCircle(Offset(x, y), .6 + rnd.nextDouble() * 1.4,
          Paint()..color = Colors.white.withValues(alpha: a));
      if (i % 11 == 0) _sparkle(c, Offset(x, y), 5 + rnd.nextDouble() * 6, a);
    }
  }

  void _sparkle(Canvas c, Offset o, double r, double a) {
    final p = Paint()
      ..color = Colors.white.withValues(alpha: a)
      ..strokeWidth = 1
      ..strokeCap = StrokeCap.round;
    c.drawLine(o.translate(-r, 0), o.translate(r, 0), p);
    c.drawLine(o.translate(0, -r), o.translate(0, r), p);
  }

  // ---------- 1. серо-голубой глаз ----------
  void _eye(Canvas c, Size s) {
    c.drawRect(Offset.zero & s, Paint()..color = const Color(0xFF05060F));
    final center = Offset(s.width / 2, s.height * .42);
    final open = _ease(_seg(t, .02, .2)) * (1 - .0);
    var blink = 1.0;
    // одно моргание на середине
    final bt = _seg(t, .34, .4);
    if (bt > 0 && bt < 1) blink = (bt - .5).abs() * 2;
    final o = open * (.15 + .85 * blink);

    final zoom = _easeIn(_seg(t, .42, .82));
    final scale = 1 + zoom * 26;
    final eyeW = s.width * .46;
    final eyeH = eyeW * .5;
    final irisR = eyeH * .86;
    final pupilR = irisR * .4 * (1 + .12 * math.sin(sec * 3));
    final look = Offset(
      math.sin(sec * 1.7) * eyeW * .05 * (1 - zoom),
      math.cos(sec * 1.3) * eyeH * .04 * (1 - zoom),
    );

    // внутри зрачка — космос (в экранных координатах, зрачок увеличивается вместе с зумом)
    final pupilScreen = pupilR * scale;
    final pupilCenter = center + look * scale;

    c.save();
    c.translate(center.dx, center.dy);
    c.scale(scale);
    c.translate(-center.dx, -center.dy);

    // веки (миндалевидный вырез)
    final lid = Path()
      ..moveTo(center.dx - eyeW, center.dy)
      ..quadraticBezierTo(center.dx, center.dy - 2 * eyeH * o, center.dx + eyeW, center.dy)
      ..quadraticBezierTo(center.dx, center.dy + 2 * eyeH * o, center.dx - eyeW, center.dy)
      ..close();
    c.save();
    c.clipPath(lid);

    // склера
    c.drawRect(
      lid.getBounds().inflate(4),
      Paint()
        ..shader = ui.Gradient.radial(
          center,
          eyeW,
          const [Color(0xFFEFF3F7), Color(0xFFC3CED8), Color(0xFF7D8C9A)],
          const [0, .65, 1],
        ),
    );
    // радужка серо-голубая
    final ic = center + look;
    c.drawCircle(
      ic,
      irisR,
      Paint()
        ..shader = ui.Gradient.radial(
          ic,
          irisR,
          const [Color(0xFFD5E2EC), Color(0xFF8CA6BC), Color(0xFF58738A), Color(0xFF263847)],
          const [0, .45, .8, 1],
        ),
    );
    // волокна радужки
    final fib = Paint()
      ..strokeWidth = irisR * .018
      ..color = const Color(0xFFEAF3FA).withValues(alpha: .22);
    for (var i = 0; i < 46; i++) {
      final a = i / 46 * math.pi * 2;
      final r0 = pupilR * 1.15;
      final r1 = irisR * (.7 + .25 * ((i * 37) % 10) / 10);
      c.drawLine(ic + Offset(math.cos(a), math.sin(a)) * r0,
          ic + Offset(math.cos(a), math.sin(a)) * r1, fib);
    }
    // тёмный ободок
    c.drawCircle(
      ic,
      irisR,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = irisR * .1
        ..color = const Color(0xFF18242F),
    );
    // зрачок (внутри позже нарисуем космос)
    c.drawCircle(ic, pupilR, Paint()..color = const Color(0xFF020309));
    // блик
    c.drawCircle(ic + Offset(-irisR * .3, -irisR * .32), irisR * .13,
        Paint()..color = Colors.white.withValues(alpha: .85 * (1 - zoom)));
    c.drawCircle(ic + Offset(irisR * .22, irisR * .3), irisR * .05,
        Paint()..color = Colors.white.withValues(alpha: .5 * (1 - zoom)));
    // тень от верхнего века
    c.drawRect(
      lid.getBounds(),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset(0, center.dy - eyeH * o),
          Offset(0, center.dy),
          [Colors.black.withValues(alpha: .55), Colors.transparent],
        ),
    );
    // строки как «растр»
    final line = Paint()
      ..strokeWidth = .6
      ..color = Colors.black.withValues(alpha: .1);
    for (var y = center.dy - eyeH; y < center.dy + eyeH; y += 3.2) {
      c.drawLine(Offset(center.dx - eyeW, y), Offset(center.dx + eyeW, y), line);
    }
    c.restore();

    // контур век
    c.drawPath(
      lid,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..strokeJoin = StrokeJoin.round
        ..color = const Color(0xFF9FB6C8).withValues(alpha: .8),
    );
    c.restore();

    // космос в зрачке
    if (zoom > .02 || t > .3) {
      final reveal = _ease(_seg(t, .48, .8));
      c.save();
      c.clipPath(Path()..addOval(Rect.fromCircle(center: pupilCenter, radius: pupilScreen)));
      _space(c, s, .15 + .85 * reveal);
      c.restore();
    }
    // лёгкое затемнение краёв
    c.drawRect(
      Offset.zero & s,
      Paint()
        ..shader = ui.Gradient.radial(
          s.center(Offset.zero),
          s.longestSide * .75,
          [Colors.transparent, Colors.black.withValues(alpha: .45 * (1 - zoom))],
        ),
    );
  }

  // ---------- 2. туманность ----------
  void _nebula(Canvas c, Size s) {
    c.drawRect(Offset.zero & s, Paint()..color = const Color(0xFF04050C));
    final center = Offset(s.width / 2, s.height * .42);
    final gather = _ease(_seg(t, .05, .62));
    final glow = _ease(_seg(t, .4, .8));
    final rnd = math.Random(3);
    final maxR = s.shortestSide * .55;
    for (var i = 0; i < 520; i++) {
      final arm = i % 3;
      final f = rnd.nextDouble();
      final ang0 = f * 7 + arm * 2.094;
      final r0 = maxR * (.15 + f * .85);
      final r = r0 * (1 - gather * .78) + 4;
      final ang = ang0 + sec * (.9 + (1 - f) * 1.4) * (1 + gather);
      final p = center + Offset(math.cos(ang), math.sin(ang) * .62) * r;
      final hue = 250 + f * 90 + sec * 8;
      c.drawCircle(
        p,
        .8 + rnd.nextDouble() * 1.8,
        Paint()
          ..color = _hsl(hue, 90, 70, .35 + .5 * (1 - f))
          ..blendMode = BlendMode.plus,
      );
    }
    c.drawCircle(
      center,
      s.shortestSide * (.05 + .22 * glow),
      Paint()
        ..shader = ui.Gradient.radial(
          center,
          s.shortestSide * (.05 + .22 * glow),
          [
            Colors.white.withValues(alpha: .9 * glow),
            const Color(0xFF7C5CFF).withValues(alpha: .5 * glow),
            Colors.transparent,
          ],
          const [0, .35, 1],
        )
        ..blendMode = BlendMode.plus,
    );
  }

  // ---------- 3. звёздный взрыв ----------
  void _burst(Canvas c, Size s) {
    c.drawRect(Offset.zero & s, Paint()..color = const Color(0xFF04050C));
    final center = Offset(s.width / 2, s.height * .42);
    final grow = _ease(_seg(t, .05, .34));
    final boom = _seg(t, .38, .78);
    final base = s.shortestSide * .16;

    if (boom < .02) {
      final pulse = 1 + .08 * math.sin(sec * 9);
      _star(c, center, base * grow * pulse, grow);
    } else {
      // вспышка
      final flash = (1 - boom) * (1 - boom);
      c.drawCircle(
        center,
        base * (1.2 + boom * 5),
        Paint()
          ..shader = ui.Gradient.radial(center, base * (1.2 + boom * 5), [
            Colors.white.withValues(alpha: .9 * flash),
            const Color(0xFFFFC857).withValues(alpha: .4 * flash),
            Colors.transparent,
          ], const [0, .4, 1])
          ..blendMode = BlendMode.plus,
      );
      final rnd = math.Random(11);
      for (var i = 0; i < 160; i++) {
        final a = rnd.nextDouble() * math.pi * 2;
        final v = .3 + rnd.nextDouble();
        final d = s.shortestSide * .7 * _ease(boom) * v;
        final p = center + Offset(math.cos(a), math.sin(a)) * d;
        final fade = (1 - boom * .6);
        c.drawCircle(
          p,
          .9 + rnd.nextDouble() * 2,
          Paint()
            ..color = _hsl(40 + rnd.nextDouble() * 280, 95, 68, .85 * fade)
            ..blendMode = BlendMode.plus,
        );
        if (i % 9 == 0) _sparkle(c, p, 4 + rnd.nextDouble() * 5, fade);
      }
    }
  }

  void _star(Canvas c, Offset o, double r, double a) {
    if (r <= 0) return;
    final path = Path();
    for (var i = 0; i < 10; i++) {
      final rr = i.isEven ? r : r * .45;
      final ang = -math.pi / 2 + i * math.pi / 5;
      final p = o + Offset(math.cos(ang), math.sin(ang)) * rr;
      i == 0 ? path.moveTo(p.dx, p.dy) : path.lineTo(p.dx, p.dy);
    }
    path.close();
    c.drawCircle(
      o,
      r * 2.2,
      Paint()
        ..shader = ui.Gradient.radial(o, r * 2.2,
            [const Color(0xFFFFD86B).withValues(alpha: .5 * a), Colors.transparent]),
    );
    c.drawPath(
      path,
      Paint()
        ..shader = ui.Gradient.linear(
          o.translate(-r, -r),
          o.translate(r, r),
          const [Color(0xFFFFF3B0), Color(0xFFFFB02E)],
        ),
    );
  }
}
