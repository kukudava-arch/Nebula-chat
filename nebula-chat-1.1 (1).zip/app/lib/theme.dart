import 'dart:math' as math;
import 'package:flutter/material.dart';

import 'app_state.dart';

/// Палитра «космос».
class NebulaColors {
  static const bg = Color(0xFF0B0B1E);
  static const bgDeep = Color(0xFF070714);
  static const surface = Color(0xFF16163A);
  static const surfaceHi = Color(0xFF1F1F4D);
  static const accent = Color(0xFF7C5CFF);
  static const accent2 = Color(0xFF22D3EE);
  static const text = Color(0xFFEDEBFF);
  static const textDim = Color(0xFF9A98C7);
  static const danger = Color(0xFFFF5470);
  static const success = Color(0xFF34D399);

  static const gradient = LinearGradient(
    colors: [accent, accent2],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: NebulaColors.bg,
    colorScheme: const ColorScheme.dark(
      primary: NebulaColors.accent,
      secondary: NebulaColors.accent2,
      surface: NebulaColors.surface,
      error: NebulaColors.danger,
    ),
    textTheme: base.textTheme.apply(
      bodyColor: NebulaColors.text,
      displayColor: NebulaColors.text,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      foregroundColor: NebulaColors.text,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: NebulaColors.surface,
      hintStyle: const TextStyle(color: NebulaColors.textDim),
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: NebulaColors.accent, width: 1.5),
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: NebulaColors.surfaceHi,
      contentTextStyle: const TextStyle(color: NebulaColors.text),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    pageTransitionsTheme: const PageTransitionsTheme(builders: {
      TargetPlatform.android: _FadeSlideTransitions(),
      TargetPlatform.iOS: _FadeSlideTransitions(),
    }),
  );
}

/// Плавный переход между экранами: лёгкий сдвиг + затухание.
class _FadeSlideTransitions extends PageTransitionsBuilder {
  const _FadeSlideTransitions();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
    return FadeTransition(
      opacity: curved,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0.06, 0),
          end: Offset.zero,
        ).animate(curved),
        child: child,
      ),
    );
  }
}

/// Живой фон: тёмный градиент, мерцающие звёзды и медленно плывущие «туманности».
class SpaceBackground extends StatefulWidget {
  final Widget child;
  const SpaceBackground({super.key, required this.child});

  @override
  State<SpaceBackground> createState() => _SpaceBackgroundState();
}

class _SpaceBackgroundState extends State<SpaceBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final List<_Star> _stars;

  @override
  void initState() {
    super.initState();
    final rnd = math.Random(7);
    _stars = List.generate(
      70,
      (_) => _Star(rnd.nextDouble(), rnd.nextDouble(), rnd.nextDouble() * 1.4 + 0.4,
          rnd.nextDouble() * math.pi * 2),
    );
    _c = AnimationController(vsync: this, duration: const Duration(seconds: 24))
      ..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        RepaintBoundary(
          child: AnimatedBuilder(
            animation: _c,
            builder: (_, __) => CustomPaint(painter: _SpacePainter(_c.value, _stars)),
          ),
        ),
        widget.child,
      ],
    );
  }
}

class _Star {
  final double x, y, r, phase;
  _Star(this.x, this.y, this.r, this.phase);
}

class _SpacePainter extends CustomPainter {
  final double t;
  final List<_Star> stars;
  _SpacePainter(this.t, this.stars);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF12123A), NebulaColors.bg, NebulaColors.bgDeep],
        ).createShader(rect),
    );

    final a = t * math.pi * 2;
    _blob(
      canvas,
      Offset(size.width * (0.25 + 0.08 * math.sin(a)), size.height * (0.2 + 0.05 * math.cos(a))),
      size.width * 0.7,
      NebulaColors.accent.withValues(alpha: 0.22),
    );
    _blob(
      canvas,
      Offset(size.width * (0.8 + 0.07 * math.cos(a)), size.height * (0.75 + 0.06 * math.sin(a))),
      size.width * 0.65,
      NebulaColors.accent2.withValues(alpha: 0.14),
    );

    final p = Paint();
    for (final s in stars) {
      final tw = 0.5 + 0.5 * math.sin(a * 3 + s.phase);
      p.color = Colors.white.withValues(alpha: 0.25 + 0.6 * tw);
      canvas.drawCircle(Offset(s.x * size.width, s.y * size.height), s.r, p);
    }
  }

  void _blob(Canvas canvas, Offset c, double r, Color color) {
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..shader = RadialGradient(colors: [color, color.withValues(alpha: 0)])
            .createShader(Rect.fromCircle(center: c, radius: r)),
    );
  }

  @override
  bool shouldRepaint(covariant _SpacePainter old) => old.t != t;
}

/// Круглый аватар. Если задан [user] и у пользователя есть свой аватар
/// («эмодзи|оттенок»), рисуется он, иначе буква на градиенте.
class NebulaAvatar extends StatelessWidget {
  final String name;
  final String? user;
  final double size;
  const NebulaAvatar({super.key, required this.name, this.user, this.size = 48});

  @override
  Widget build(BuildContext context) {
    final look = user == null ? const Look() : AppState.I.lookOf(user!);
    var hue = (name.codeUnits.fold<int>(0, (a, b) => (a * 31 + b) & 0xFFFFFF) % 360).toDouble();
    var symbol = name.trim().isEmpty ? '?' : name.trim().characters.first.toUpperCase();
    var emoji = false;
    final parts = look.avatar.split('|');
    if (parts.length == 2 && parts[0].isNotEmpty) {
      symbol = parts[0];
      hue = (double.tryParse(parts[1]) ?? hue) % 360;
      emoji = true;
    }
    final c1 = HSLColor.fromAHSL(1, hue, 0.7, 0.55).toColor();
    final c2 = HSLColor.fromAHSL(1, (hue + 50) % 360, 0.75, 0.4).toColor();
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(colors: [c1, c2], begin: Alignment.topLeft, end: Alignment.bottomRight),
        boxShadow: [BoxShadow(color: c1.withValues(alpha: 0.35), blurRadius: 12)],
      ),
      child: Text(
        symbol,
        style: TextStyle(
          fontSize: size * (emoji ? 0.5 : 0.42),
          fontWeight: FontWeight.w700,
          color: Colors.white,
        ),
      ),
    );
  }
}

/// Имя пользователя; у премиум-аккаунтов может быть цветным.
class NickText extends StatelessWidget {
  final String user, name;
  final TextStyle? style;
  const NickText({super.key, required this.user, required this.name, this.style});

  @override
  Widget build(BuildContext context) {
    final look = AppState.I.lookOf(user);
    Color? color;
    if (look.nickColor.length == 7) {
      final v = int.tryParse(look.nickColor.substring(1), radix: 16);
      if (v != null) color = Color(0xFF000000 | v);
    }
    return Text(
      name,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: (style ?? const TextStyle()).copyWith(color: color),
    );
  }
}

/// Кнопка с градиентом.
class GradientButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool busy;
  const GradientButton({super.key, required this.label, this.onPressed, this.busy = false});

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !busy;
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 200),
      opacity: enabled ? 1 : 0.6,
      child: Material(
        color: Colors.transparent,
        child: Ink(
          decoration: BoxDecoration(
            gradient: NebulaColors.gradient,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: NebulaColors.accent.withValues(alpha: 0.4), blurRadius: 18, offset: const Offset(0, 6))],
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: enabled ? onPressed : null,
            child: Container(
              height: 52,
              alignment: Alignment.center,
              child: busy
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white),
                    )
                  : Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white)),
            ),
          ),
        ),
      ),
    );
  }
}
