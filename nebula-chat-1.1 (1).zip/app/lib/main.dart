import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app_state.dart';
import 'call_service.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'helper/helper_overlay.dart';
import 'intro/intro_screen.dart';
import 'notify.dart';
import 'helper/helper_service.dart';
import 'theme.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: NebulaColors.bgDeep,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  await AppState.I.init();
  await Notify.I.init();
  _syncService();
  AppState.I.loggedIn.addListener(_syncService);
  await HelperService.I.init();
  await CallService.I.init(navigatorKey);
  runApp(const NebulaApp());
}

/// Фоновая служба и разрешения: нужны только вошедшему пользователю (не демо).
void _syncService() {
  if (AppState.I.loggedIn.value && !AppState.I.demo) {
    Notify.I.askPermissions().then((_) => Notify.I.startService());
  } else {
    Notify.I.stopService();
  }
}

/// Показывает заставку при каждом запуске, потом само приложение.
class IntroGate extends StatefulWidget {
  final Widget child;
  const IntroGate({super.key, required this.child});

  @override
  State<IntroGate> createState() => _IntroGateState();
}

class _IntroGateState extends State<IntroGate> {
  bool _done = false;

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 600),
      switchInCurve: Curves.easeOut,
      child: _done
          ? widget.child
          : IntroScreen(
              key: const ValueKey('intro'),
              style: AppState.I.intro,
              onDone: () => setState(() => _done = true),
            ),
    );
  }
}

class NebulaApp extends StatelessWidget {
  const NebulaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nebula Chat',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      navigatorKey: navigatorKey,
      builder: (context, child) => HelperOverlay(child: child ?? const SizedBox()),
      home: IntroGate(
        child: ValueListenableBuilder<bool>(
        valueListenable: AppState.I.loggedIn,
        builder: (context, ok, _) => AnimatedSwitcher(
          duration: const Duration(milliseconds: 450),
          switchInCurve: Curves.easeOutCubic,
          child: ok
              ? const HomeScreen(key: ValueKey('home'))
              : const AuthScreen(key: ValueKey('auth')),
        ),
      ),
      ),
    );
  }
}
