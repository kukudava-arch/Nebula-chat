#!/usr/bin/env bash
# Установка сервера Nebula Chat на Ubuntu 22.04/24.04 (запускать от root).
# Использование:  bash install.sh nebula-chat-1.1.zip
set -euo pipefail

ZIP="${1:-nebula-chat-1.1.zip}"
APP_DIR=/opt/nebula
[ -f "$ZIP" ] || { echo "Не найден архив $ZIP"; exit 1; }

apt-get update -y
apt-get install -y unzip curl ca-certificates ufw
if ! command -v node >/dev/null 2>&1; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

mkdir -p "$APP_DIR"
unzip -oq "$ZIP" 'server/*' -d "$APP_DIR"
cd "$APP_DIR/server"
npm install --omit=dev

mkdir -p /var/lib/nebula
cat > /etc/systemd/system/nebula.service <<UNIT
[Unit]
Description=Nebula Chat server
After=network.target

[Service]
WorkingDirectory=$APP_DIR/server
Environment=PORT=3000
Environment=DATA_FILE=/var/lib/nebula/data.json
Environment=ADMIN_USERS=davtroadmin1
ExecStart=/usr/bin/node server.js
Restart=always
User=root

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable --now nebula.service

ufw allow 22/tcp || true
ufw allow 3000/tcp || true
ufw --force enable || true

IP=$(curl -s https://api.ipify.org || echo "ВАШ_IP")
echo
echo "Готово. Адрес сервера: http://$IP:3000"
echo "Проверка: откройте http://$IP:3000/health в браузере."
