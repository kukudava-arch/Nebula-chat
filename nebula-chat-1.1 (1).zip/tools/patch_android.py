#!/usr/bin/env python3
"""Донастраивает Android-проект, созданный командой `flutter create`:
разрешения (интернет, микрофон, камера), доступ по http к тестовому серверу,
название приложения и минимальная версия Android для WebRTC.
Запускать из папки app/."""
import pathlib
import re
import sys

ROOT = pathlib.Path("android")
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"

PERMISSIONS = """
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.CHANGE_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.CAMERA"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
    <uses-permission android:name="android.permission.USE_FULL_SCREEN_INTENT"/>
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"/>
    <uses-feature android:name="android.hardware.camera" android:required="false"/>
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false"/>
"""


def patch_manifest() -> None:
    text = MANIFEST.read_text(encoding="utf-8")

    if "android.permission.RECORD_AUDIO" not in text:
        text, n = re.subn(r"(<manifest[^>]*>)", lambda m: m.group(1) + PERMISSIONS, text, count=1)
        if n != 1:
            sys.exit("Не нашёл тег <manifest> в AndroidManifest.xml")

    if "usesCleartextTraffic" not in text:
        text, n = re.subn(
            r"<application",
            '<application\n        android:usesCleartextTraffic="true"',
            text,
            count=1,
        )
        if n != 1:
            sys.exit("Не нашёл тег <application> в AndroidManifest.xml")

    if "flutter_foreground_task" not in text:
        service = (
            '<service android:name="com.pravera.flutter_foreground_task.service.ForegroundService"\n'
            '            android:foregroundServiceType="dataSync"\n'
            '            android:exported="false"/>\n    '
        )
        text, n = re.subn(r"</application>", lambda m: service + "</application>", text, count=1)
        if n != 1:
            sys.exit("Не нашёл </application> в AndroidManifest.xml")

    if "android:showWhenLocked" not in text:
        text = re.sub(
            r"<activity",
            '<activity\n            android:showWhenLocked="true"\n            android:turnScreenOn="true"',
            text,
            count=1,
        )

    text = re.sub(r'android:label="[^"]*"', 'android:label="Nebula Chat"', text, count=1)
    MANIFEST.write_text(text, encoding="utf-8")
    print("AndroidManifest.xml: OK")


def patch_min_sdk() -> None:
    for name in ("app/build.gradle.kts", "app/build.gradle"):
        path = ROOT / name
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        new = re.sub(r"minSdk\s*=\s*flutter\.minSdkVersion", "minSdk = 24", text)
        new = re.sub(r"minSdkVersion\s+flutter\.minSdkVersion", "minSdkVersion 24", new)
        if new != text:
            path.write_text(new, encoding="utf-8")
            print(f"{name}: minSdk = 24")
        else:
            print(f"{name}: minSdk не менялся (уже задан)")
        return
    print("build.gradle не найден — minSdk не менялся")


def patch_server_url() -> None:
    """Если в корне репозитория есть server_url.txt, адрес из него вшивается в приложение."""
    here = pathlib.Path(__file__).resolve().parent
    candidates = [here.parent.parent / "server_url.txt", here.parent / "server_url.txt"]
    src = next((c for c in candidates if c.exists()), None)
    if src is None:
        print("server_url.txt не найден: адрес сервера не вшит")
        return
    url = "".join(src.read_text(encoding="utf-8").split())
    if not url:
        print("server_url.txt пуст")
        return
    target = here.parent / "app" / "lib" / "app_state.dart"
    text = target.read_text(encoding="utf-8")
    new, n = re.subn(r"const String kDefaultServer = '[^']*';", lambda m: f"const String kDefaultServer = '{url}';", text, count=1)
    if n != 1:
        sys.exit("Не нашёл kDefaultServer в app_state.dart")
    target.write_text(new, encoding="utf-8")
    print(f"Адрес сервера вшит: {url}")


def patch_desugar() -> None:
    """flutter_local_notifications требует desugaring библиотек Java."""
    for name in ("app/build.gradle.kts", "app/build.gradle"):
        path = ROOT / name
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        if "coreLibraryDesugaring" in text:
            print(f"{name}: desugaring уже включён")
            return
        kts = name.endswith(".kts")
        flag = "isCoreLibraryDesugaringEnabled = true" if kts else "coreLibraryDesugaringEnabled true"
        new, n = re.subn(r"(compileOptions\s*\{)", lambda m: m.group(1) + "\n        " + flag, text, count=1)
        if n != 1:
            sys.exit(f"{name}: не нашёл compileOptions для desugaring")
        dep = (
            '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")\n}\n'
            if kts
            else "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.5'\n}\n"
        )
        path.write_text(new + dep, encoding="utf-8")
        print(f"{name}: desugaring включён")
        return
    sys.exit("build.gradle не найден — desugaring не включён")


if __name__ == "__main__":
    if not MANIFEST.exists():
        sys.exit("Запускайте из папки app/ после `flutter create`")
    patch_manifest()
    patch_min_sdk()
    patch_desugar()
    patch_server_url()
