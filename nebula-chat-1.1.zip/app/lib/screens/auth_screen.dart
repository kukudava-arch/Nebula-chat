import 'package:flutter/material.dart';

import '../app_state.dart';
import '../theme.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool _register = false;
  bool _busy = false;
  bool _hidePass = true;
  final _server = TextEditingController(text: AppState.I.serverUrl);
  final _user = TextEditingController();
  final _pass = TextEditingController();
  final _name = TextEditingController();

  @override
  void dispose() {
    _server.dispose();
    _user.dispose();
    _pass.dispose();
    _name.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    setState(() => _busy = true);
    final err = await AppState.I.authenticate(
      register: _register,
      server: _server.text,
      user: _user.text,
      password: _pass.text,
      name: _name.text,
    );
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(err)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return SpaceBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: 1),
                  duration: const Duration(milliseconds: 700),
                  curve: Curves.easeOutCubic,
                  builder: (context, v, child) => Opacity(
                    opacity: v,
                    child: Transform.translate(offset: Offset(0, (1 - v) * 24), child: child),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      ShaderMask(
                        shaderCallback: (r) => NebulaColors.gradient.createShader(r),
                        child: const Text(
                          'Nebula',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 48,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Чаты, звонки и сделки в одном месте',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: NebulaColors.textDim, fontSize: 14),
                      ),
                      const SizedBox(height: 32),
                      TextField(
                        controller: _server,
                        keyboardType: TextInputType.url,
                        autocorrect: false,
                        decoration: const InputDecoration(
                          hintText: 'Адрес сервера (http://192.168.0.10:3000)',
                          prefixIcon: Icon(Icons.dns_outlined, color: NebulaColors.textDim),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _user,
                        autocorrect: false,
                        enableSuggestions: false,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          hintText: 'Логин',
                          prefixIcon: Icon(Icons.alternate_email, color: NebulaColors.textDim),
                        ),
                      ),
                      AnimatedSize(
                        duration: const Duration(milliseconds: 280),
                        curve: Curves.easeOutCubic,
                        child: _register
                            ? Padding(
                                padding: const EdgeInsets.only(top: 12),
                                child: TextField(
                                  controller: _name,
                                  textInputAction: TextInputAction.next,
                                  textCapitalization: TextCapitalization.words,
                                  decoration: const InputDecoration(
                                    hintText: 'Имя (как вас будут видеть)',
                                    prefixIcon:
                                        Icon(Icons.badge_outlined, color: NebulaColors.textDim),
                                  ),
                                ),
                              )
                            : const SizedBox(width: double.infinity),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _pass,
                        obscureText: _hidePass,
                        onSubmitted: (_) => _busy ? null : _submit(),
                        decoration: InputDecoration(
                          hintText: 'Пароль',
                          prefixIcon:
                              const Icon(Icons.lock_outline, color: NebulaColors.textDim),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _hidePass ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                              color: NebulaColors.textDim,
                            ),
                            onPressed: () => setState(() => _hidePass = !_hidePass),
                          ),
                        ),
                      ),
                      const SizedBox(height: 22),
                      GradientButton(
                        label: _register ? 'Создать аккаунт' : 'Войти',
                        busy: _busy,
                        onPressed: _submit,
                      ),
                      const SizedBox(height: 10),
                      TextButton(
                        onPressed: _busy ? null : () => setState(() => _register = !_register),
                        child: Text(
                          _register ? 'Уже есть аккаунт? Войти' : 'Нет аккаунта? Зарегистрироваться',
                          style: const TextStyle(color: NebulaColors.accent2),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
