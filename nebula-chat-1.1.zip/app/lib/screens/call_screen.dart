import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../call_service.dart';
import '../theme.dart';
import '../utils.dart';

class CallScreen extends StatelessWidget {
  const CallScreen({super.key});

  String _status(CallService s) {
    switch (s.phase) {
      case CallPhase.calling:
        return 'Вызов…';
      case CallPhase.incoming:
        return s.video ? 'Входящий видеозвонок' : 'Входящий звонок';
      case CallPhase.connecting:
        return 'Соединение…';
      case CallPhase.active:
        return formatDuration(s.seconds);
      case CallPhase.ended:
        return s.endReason ?? 'Звонок завершён';
      case CallPhase.idle:
        return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: ListenableBuilder(
        listenable: CallService.I,
        builder: (context, _) {
          final s = CallService.I;
          final showRemoteVideo = s.video && s.hasRemoteVideo && s.phase != CallPhase.ended;
          final showLocalPreview =
              s.video && s.hasLocalVideo && !s.cameraOff && s.phase != CallPhase.ended;
          final ringing = s.phase == CallPhase.incoming || s.phase == CallPhase.calling;

          return Scaffold(
            backgroundColor: NebulaColors.bg,
            body: Stack(
              fit: StackFit.expand,
              children: [
                if (showRemoteVideo)
                  RTCVideoView(
                    s.remoteRenderer,
                    objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                  )
                else
                  const SpaceBackground(child: SizedBox.expand()),
                if (showRemoteVideo)
                  DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.black.withValues(alpha: 0.55),
                          Colors.transparent,
                          Colors.black.withValues(alpha: 0.65),
                        ],
                        stops: const [0, 0.4, 1],
                      ),
                    ),
                  ),
                SafeArea(
                  child: Column(
                    children: [
                      const SizedBox(height: 28),
                      Text(
                        s.peerName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 8),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 250),
                        child: Text(
                          _status(s),
                          key: ValueKey(_status(s)),
                          style: TextStyle(
                            fontSize: 16,
                            color: s.phase == CallPhase.ended
                                ? NebulaColors.danger
                                : NebulaColors.textDim,
                            fontFeatures: const [FontFeature.tabularFigures()],
                          ),
                        ),
                      ),
                      Expanded(
                        child: Center(
                          child: showRemoteVideo
                              ? const SizedBox.shrink()
                              : _PulsingAvatar(name: s.peerName, pulsing: ringing),
                        ),
                      ),
                      if (s.phase == CallPhase.incoming)
                        _IncomingControls(service: s)
                      else
                        _ActiveControls(service: s),
                      const SizedBox(height: 34),
                    ],
                  ),
                ),
                if (showLocalPreview)
                  Positioned(
                    top: MediaQuery.of(context).padding.top + 96,
                    right: 16,
                    width: 104,
                    height: 144,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: RTCVideoView(
                        s.localRenderer,
                        mirror: true,
                        objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _IncomingControls extends StatelessWidget {
  final CallService service;
  const _IncomingControls({required this.service});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _RoundButton(
          icon: Icons.call_end,
          color: NebulaColors.danger,
          size: 72,
          label: 'Отклонить',
          onTap: service.reject,
        ),
        _RoundButton(
          icon: service.video ? Icons.videocam : Icons.call,
          color: NebulaColors.success,
          size: 72,
          label: 'Принять',
          onTap: service.accept,
        ),
      ],
    );
  }
}

class _ActiveControls extends StatelessWidget {
  final CallService service;
  const _ActiveControls({required this.service});

  @override
  Widget build(BuildContext context) {
    final ended = service.phase == CallPhase.ended;
    return Opacity(
      opacity: ended ? 0.4 : 1,
      child: IgnorePointer(
        ignoring: ended,
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _RoundButton(
                  icon: service.muted ? Icons.mic_off : Icons.mic,
                  active: service.muted,
                  label: 'Микрофон',
                  onTap: service.toggleMute,
                ),
                _RoundButton(
                  icon: service.speakerOn ? Icons.volume_up : Icons.hearing,
                  active: service.speakerOn,
                  label: 'Динамик',
                  onTap: service.toggleSpeaker,
                ),
                if (service.video) ...[
                  _RoundButton(
                    icon: service.cameraOff ? Icons.videocam_off : Icons.videocam,
                    active: service.cameraOff,
                    label: 'Камера',
                    onTap: service.toggleCamera,
                  ),
                  _RoundButton(
                    icon: Icons.cameraswitch,
                    label: 'Сменить',
                    onTap: service.switchCamera,
                  ),
                ],
              ],
            ),
            const SizedBox(height: 28),
            _RoundButton(
              icon: Icons.call_end,
              color: NebulaColors.danger,
              size: 72,
              onTap: service.hangup,
            ),
          ],
        ),
      ),
    );
  }
}

class _RoundButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool active;
  final Color? color;
  final double size;
  final String? label;
  const _RoundButton({
    required this.icon,
    required this.onTap,
    this.active = false,
    this.color,
    this.size = 60,
    this.label,
  });

  @override
  Widget build(BuildContext context) {
    final bg = color ?? (active ? Colors.white : Colors.white.withValues(alpha: 0.14));
    final fg = color != null ? Colors.white : (active ? NebulaColors.bgDeep : Colors.white);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: bg,
              boxShadow: color != null
                  ? [BoxShadow(color: color!.withValues(alpha: 0.45), blurRadius: 20)]
                  : null,
            ),
            child: Icon(icon, color: fg, size: size * 0.42),
          ),
        ),
        if (label != null) ...[
          const SizedBox(height: 8),
          Text(label!, style: const TextStyle(fontSize: 12, color: NebulaColors.textDim)),
        ],
      ],
    );
  }
}

/// Аватар с расходящимися кольцами, пока идёт вызов.
class _PulsingAvatar extends StatefulWidget {
  final String name;
  final bool pulsing;
  const _PulsingAvatar({required this.name, required this.pulsing});

  @override
  State<_PulsingAvatar> createState() => _PulsingAvatarState();
}

class _PulsingAvatarState extends State<_PulsingAvatar> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2400))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 280,
      height: 280,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, child) {
          return Stack(
            alignment: Alignment.center,
            children: [
              if (widget.pulsing)
                for (var i = 0; i < 3; i++) _ring((_c.value + i / 3) % 1),
              child!,
            ],
          );
        },
        child: NebulaAvatar(name: widget.name, size: 132),
      ),
    );
  }

  Widget _ring(double t) {
    return Opacity(
      opacity: ((1 - t) * 0.5).clamp(0.0, 1.0),
      child: Container(
        width: 132 + t * 148,
        height: 132 + t * 148,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: NebulaColors.accent2, width: 2),
        ),
      ),
    );
  }
}
