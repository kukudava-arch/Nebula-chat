import 'package:flutter/material.dart';

import '../app_state.dart';
import '../theme.dart';
import '../utils.dart';
import 'chat_screen.dart';

class ChatsTab extends StatelessWidget {
  const ChatsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.I,
      builder: (context, _) {
        final chats = AppState.I.chats;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 14, 20, 8),
              child: Text('Чаты', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
            ),
            Expanded(
              child: chats.isEmpty
                  ? const _EmptyChats()
                  : ListView.builder(
                      padding: const EdgeInsets.only(bottom: 90),
                      itemCount: chats.length,
                      itemBuilder: (context, i) => _ChatTile(
                        key: ValueKey(chats[i].user),
                        chat: chats[i],
                        index: i,
                      ),
                    ),
            ),
          ],
        );
      },
    );
  }
}

class _ChatTile extends StatelessWidget {
  final ChatPreview chat;
  final int index;
  const _ChatTile({super.key, required this.chat, required this.index});

  @override
  Widget build(BuildContext context) {
    final mine = chat.from == AppState.I.username;
    final delay = (index < 8 ? index : 8) * 50;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 320 + delay),
      curve: Curves.easeOutCubic,
      builder: (context, v, child) => Opacity(
        opacity: v.clamp(0.0, 1.0),
        child: Transform.translate(offset: Offset(0, (1 - v) * 16), child: child),
      ),
      child: InkWell(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => ChatScreen(peer: chat.user, peerName: chat.displayName),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          child: Row(
            children: [
              NebulaAvatar(name: chat.displayName, size: 54),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            chat.displayName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                          ),
                        ),
                        Text(
                          formatClock(chat.ts),
                          style: const TextStyle(fontSize: 12, color: NebulaColors.textDim),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      mine ? 'Вы: ${chat.text}' : chat.text,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: NebulaColors.textDim, fontSize: 14),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyChats extends StatelessWidget {
  const _EmptyChats();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.auto_awesome, size: 56, color: NebulaColors.accent),
            SizedBox(height: 16),
            Text('Пока тихо', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            SizedBox(height: 8),
            Text(
              'Нажмите кнопку внизу справа и найдите человека по логину, чтобы начать чат.',
              textAlign: TextAlign.center,
              style: TextStyle(color: NebulaColors.textDim, height: 1.4),
            ),
          ],
        ),
      ),
    );
  }
}
