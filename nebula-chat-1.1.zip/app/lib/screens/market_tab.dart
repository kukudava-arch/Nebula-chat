import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme.dart';

/// Заглушка маркета: здесь позже появятся объявления, сделки и ИИ-помощник.
class MarketTab extends StatefulWidget {
  const MarketTab({super.key});

  @override
  State<MarketTab> createState() => _MarketTabState();
}

class _MarketTabState extends State<MarketTab> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _c,
              builder: (context, child) => Transform.translate(
                offset: Offset(0, math.sin(_c.value * math.pi * 2) * 8),
                child: child,
              ),
              child: Container(
                width: 112,
                height: 112,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: NebulaColors.gradient,
                  boxShadow: [
                    BoxShadow(
                      color: NebulaColors.accent.withValues(alpha: 0.5),
                      blurRadius: 36,
                    ),
                  ],
                ),
                child: const Icon(Icons.storefront, size: 52, color: Colors.white),
              ),
            ),
            const SizedBox(height: 28),
            const Text('Маркет — скоро',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            const Text(
              'Здесь будут объявления людей из ваших чатов: заходите в профиль, пишите продавцу '
              'и договаривайтесь о встрече.',
              textAlign: TextAlign.center,
              style: TextStyle(color: NebulaColors.textDim, height: 1.45),
            ),
            const SizedBox(height: 22),
            const Wrap(
              spacing: 8,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: [
                _Chip('Объявления'),
                _Chip('Безопасные сделки'),
                _Chip('ИИ-помощник Nebula'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  const _Chip(this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: NebulaColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: NebulaColors.accent.withValues(alpha: 0.35)),
      ),
      child: Text(label, style: const TextStyle(fontSize: 13, color: NebulaColors.text)),
    );
  }
}
