import 'dart:async';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../theme.dart';
import 'chat_screen.dart';

/// Поиск человека по логину или имени, чтобы начать чат.
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _ctrl = TextEditingController();
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    AppState.I.clearSearch(notify: false); // без notify: мы ещё в фазе построения
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _ctrl.dispose();
    super.dispose();
  }

  void _onChanged(String v) {
    _debounce?.cancel();
    if (v.trim().length < 2) {
      AppState.I.clearSearch();
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 300), () => AppState.I.search(v));
  }

  @override
  Widget build(BuildContext context) {
    return SpaceBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(title: const Text('Новый чат')),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: TextField(
                controller: _ctrl,
                autofocus: true,
                autocorrect: false,
                onChanged: _onChanged,
                decoration: const InputDecoration(
                  hintText: 'Логин или имя',
                  prefixIcon: Icon(Icons.search, color: NebulaColors.textDim),
                ),
              ),
            ),
            Expanded(
              child: AnimatedBuilder(
                animation: AppState.I,
                builder: (context, _) {
                  final q = _ctrl.text.trim();
                  final res = AppState.I.searchResults;
                  if (q.length < 2) {
                    return const _Hint('Введите минимум 2 символа');
                  }
                  if (AppState.I.searching && res.isEmpty) {
                    return const Center(
                      child: CircularProgressIndicator(color: NebulaColors.accent),
                    );
                  }
                  if (res.isEmpty) return const _Hint('Никого не найдено');
                  return ListView.builder(
                    itemCount: res.length,
                    itemBuilder: (context, i) {
                      final u = res[i];
                      return ListTile(
                        leading: NebulaAvatar(name: u.displayName, size: 46),
                        title: Text(u.displayName,
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text('@${u.username}',
                            style: const TextStyle(color: NebulaColors.textDim)),
                        onTap: () => Navigator.of(context).pushReplacement(
                          MaterialPageRoute<void>(
                            builder: (_) =>
                                ChatScreen(peer: u.username, peerName: u.displayName),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Hint extends StatelessWidget {
  final String text;
  const _Hint(this.text);

  @override
  Widget build(BuildContext context) =>
      Center(child: Text(text, style: const TextStyle(color: NebulaColors.textDim)));
}
