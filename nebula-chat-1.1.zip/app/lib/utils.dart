String _two(int n) => n.toString().padLeft(2, '0');

/// Время сообщения: сегодня — ЧЧ:ММ, иначе — ДД.ММ.
String formatClock(int ts) {
  final d = DateTime.fromMillisecondsSinceEpoch(ts);
  final now = DateTime.now();
  if (d.year == now.year && d.month == now.month && d.day == now.day) {
    return '${_two(d.hour)}:${_two(d.minute)}';
  }
  return '${_two(d.day)}.${_two(d.month)}';
}

/// Длительность звонка: ММ:СС.
String formatDuration(int sec) => '${_two(sec ~/ 60)}:${_two(sec % 60)}';
