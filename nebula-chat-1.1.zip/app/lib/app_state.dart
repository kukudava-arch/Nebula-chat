import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

/// Адрес сервера по умолчанию. Можно вписать свой, например 'http://192.168.0.10:3000'.
/// Пользователь всё равно может изменить его на экране входа.
const String kDefaultServer = '';

class ChatMessage {
  final String id, from, to, text;
  final int ts;
  ChatMessage({
    required this.id,
    required this.from,
    required this.to,
    required this.text,
    required this.ts,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> j) => ChatMessage(
        id: j['id'] as String,
        from: j['from'] as String,
        to: j['to'] as String,
        text: j['text'] as String,
        ts: (j['ts'] as num).toInt(),
      );
}

class ChatPreview {
  final String user, displayName, text, from;
  final int ts;
  ChatPreview({
    required this.user,
    required this.displayName,
    required this.text,
    required this.from,
    required this.ts,
  });

  factory ChatPreview.fromJson(Map<String, dynamic> j) => ChatPreview(
        user: j['user'] as String,
        displayName: j['displayName'] as String,
        text: j['text'] as String,
        from: j['from'] as String,
        ts: (j['ts'] as num).toInt(),
      );
}

class UserInfo {
  final String username, displayName;
  UserInfo({required this.username, required this.displayName});

  factory UserInfo.fromJson(Map<String, dynamic> j) => UserInfo(
        username: j['username'] as String,
        displayName: j['displayName'] as String,
      );
}

class CallRecord {
  final String peer, peerName;
  final bool video, incoming, answered;
  final int ts, durationSec;
  CallRecord({
    required this.peer,
    required this.peerName,
    required this.video,
    required this.incoming,
    required this.answered,
    required this.ts,
    required this.durationSec,
  });

  Map<String, dynamic> toJson() => {
        'peer': peer,
        'peerName': peerName,
        'video': video,
        'incoming': incoming,
        'answered': answered,
        'ts': ts,
        'durationSec': durationSec,
      };

  factory CallRecord.fromJson(Map<String, dynamic> j) => CallRecord(
        peer: j['peer'] as String,
        peerName: j['peerName'] as String,
        video: j['video'] as bool,
        incoming: j['incoming'] as bool,
        answered: j['answered'] as bool,
        ts: (j['ts'] as num).toInt(),
        durationSec: (j['durationSec'] as num).toInt(),
      );
}

/// Всё состояние приложения: сессия, соединение с сервером, чаты, история звонков.
class AppState extends ChangeNotifier {
  AppState._();
  static final AppState I = AppState._();

  final ValueNotifier<bool> loggedIn = ValueNotifier<bool>(false);
  late SharedPreferences _prefs;

  String serverUrl = '';
  String token = '';
  String username = '';
  String displayName = '';
  bool connected = false;

  List<ChatPreview> chats = [];
  final Map<String, List<ChatMessage>> messages = {};
  final Set<String> freshIds = {}; // сообщения, пришедшие «вживую» (для анимации)
  List<UserInfo> searchResults = [];
  bool searching = false;
  List<CallRecord> calls = [];

  WebSocketChannel? _ch;
  StreamSubscription? _sub;
  Timer? _reconnect;
  int _attempt = 0;
  bool _wantConnection = false;

  final StreamController<Map<String, dynamic>> _signals =
      StreamController<Map<String, dynamic>>.broadcast();
  Stream<Map<String, dynamic>> get signals => _signals.stream;

  final StreamController<String> _errors = StreamController<String>.broadcast();
  Stream<String> get errors => _errors.stream;
  void pushError(String text) => _errors.add(text);

  // ---------- запуск ----------
  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    serverUrl = _prefs.getString('server') ?? kDefaultServer;
    token = _prefs.getString('token') ?? '';
    username = _prefs.getString('username') ?? '';
    displayName = _prefs.getString('displayName') ?? '';

    final raw = _prefs.getString('calls');
    if (raw != null) {
      try {
        calls = (jsonDecode(raw) as List)
            .map((e) => CallRecord.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {
        calls = [];
      }
    }

    if (token.isNotEmpty && serverUrl.isNotEmpty) {
      loggedIn.value = true;
      _connect();
    }
  }

  static String normalizeServer(String s) {
    var v = s.trim();
    if (v.isEmpty) return '';
    if (!v.startsWith('http://') && !v.startsWith('https://')) v = 'http://$v';
    while (v.endsWith('/')) {
      v = v.substring(0, v.length - 1);
    }
    return v;
  }

  // ---------- вход / регистрация ----------
  /// Возвращает текст ошибки или null при успехе.
  Future<String?> authenticate({
    required bool register,
    required String server,
    required String user,
    required String password,
    String name = '',
  }) async {
    final base = normalizeServer(server);
    if (base.isEmpty) return 'Укажите адрес сервера';
    if (user.trim().isEmpty || password.isEmpty) return 'Введите логин и пароль';
    try {
      final endpoint = register ? 'register' : 'login';
      final res = await http
          .post(
            Uri.parse('$base/api/$endpoint'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'username': user.trim(),
              'password': password,
              if (register) 'displayName': name.trim(),
            }),
          )
          .timeout(const Duration(seconds: 12));
      final data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      if (res.statusCode != 200) {
        return (data['error'] as String?) ?? 'Ошибка ${res.statusCode}';
      }
      serverUrl = base;
      token = data['token'] as String;
      username = data['username'] as String;
      displayName = data['displayName'] as String;
      await _prefs.setString('server', serverUrl);
      await _prefs.setString('token', token);
      await _prefs.setString('username', username);
      await _prefs.setString('displayName', displayName);
      loggedIn.value = true;
      _connect();
      notifyListeners();
      return null;
    } on TimeoutException {
      return 'Сервер не отвечает. Проверьте адрес.';
    } catch (_) {
      return 'Не удалось подключиться к серверу';
    }
  }

  Future<void> logout() async {
    _wantConnection = false;
    _reconnect?.cancel();
    _closeChannel();
    connected = false;
    token = '';
    username = '';
    displayName = '';
    chats = [];
    messages.clear();
    freshIds.clear();
    searchResults = [];
    calls = [];
    await _prefs.remove('token');
    await _prefs.remove('username');
    await _prefs.remove('displayName');
    await _prefs.remove('calls');
    loggedIn.value = false;
    notifyListeners();
  }

  // ---------- соединение ----------
  void _connect() {
    _wantConnection = true;
    _reconnect?.cancel();
    _closeChannel();

    try {
      final base = Uri.parse(serverUrl);
      final uri = Uri(
        scheme: base.scheme == 'https' ? 'wss' : 'ws',
        host: base.host,
        port: base.hasPort ? base.port : null,
        path: '/ws',
        queryParameters: {'token': token},
      );
      final ch = IOWebSocketChannel.connect(
        uri,
        pingInterval: const Duration(seconds: 20),
      );
      _ch = ch;
      ch.ready.catchError((Object e) {
        if (_ch != ch) return;
        if (e.toString().contains('401')) {
          pushError('Сессия истекла, войдите снова');
          logout();
        }
      });
      _sub = ch.stream.listen(
        _onData,
        onDone: () => _onClosed(ch),
        onError: (Object _) => _onClosed(ch),
        cancelOnError: true,
      );
    } catch (_) {
      _scheduleReconnect();
    }
  }

  void _closeChannel() {
    _sub?.cancel();
    _sub = null;
    try {
      _ch?.sink.close();
    } catch (_) {}
    _ch = null;
  }

  void _onClosed(WebSocketChannel ch) {
    if (_ch != ch) return;
    connected = false;
    notifyListeners();
    if (_wantConnection) _scheduleReconnect();
  }

  void _scheduleReconnect() {
    _reconnect?.cancel();
    final secs = math.min(30, 1 << math.min(_attempt, 5));
    _attempt++;
    _reconnect = Timer(Duration(seconds: secs), () {
      if (_wantConnection) _connect();
    });
  }

  /// Вызывается при возврате приложения на передний план.
  void ensureConnected() {
    if (_wantConnection && !connected) {
      _attempt = 0;
      _connect();
    }
  }

  void _send(Map<String, dynamic> m) {
    try {
      _ch?.sink.add(jsonEncode(m));
    } catch (_) {}
  }

  void _onData(dynamic raw) {
    Map<String, dynamic> m;
    try {
      m = jsonDecode(raw as String) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final type = m['type'] as String?;
    switch (type) {
      case 'hello':
        connected = true;
        _attempt = 0;
        requestChats();
        notifyListeners();
        break;
      case 'chats':
        chats = (m['chats'] as List)
            .map((e) => ChatPreview.fromJson(e as Map<String, dynamic>))
            .toList();
        notifyListeners();
        break;
      case 'history':
        final w = m['with'] as String;
        messages[w] = (m['messages'] as List)
            .map((e) => ChatMessage.fromJson(e as Map<String, dynamic>))
            .toList();
        notifyListeners();
        break;
      case 'message':
        final msg = ChatMessage.fromJson(m['msg'] as Map<String, dynamic>);
        final other = msg.from == username ? msg.to : msg.from;
        final list = messages.putIfAbsent(other, () => []);
        if (!list.any((x) => x.id == msg.id)) {
          list.add(msg);
          freshIds.add(msg.id);
        }
        requestChats();
        notifyListeners();
        break;
      case 'search':
        searchResults = (m['users'] as List)
            .map((e) => UserInfo.fromJson(e as Map<String, dynamic>))
            .toList();
        searching = false;
        notifyListeners();
        break;
      case 'error':
        pushError((m['error'] as String?) ?? 'Ошибка');
        break;
      default:
        if (type != null && type.startsWith('call_')) _signals.add(m);
    }
  }

  // ---------- действия ----------
  void requestChats() => _send({'type': 'chats'});

  void loadHistory(String peer) => _send({'type': 'history', 'with': peer});

  void search(String q) {
    searching = q.trim().length >= 2;
    _send({'type': 'search', 'q': q});
    notifyListeners();
  }

  void clearSearch({bool notify = true}) {
    searchResults = [];
    searching = false;
    if (notify) notifyListeners();
  }

  void sendMessage(String to, String text) {
    if (!connected) {
      pushError('Нет соединения с сервером');
      return;
    }
    _send({'type': 'send', 'to': to, 'text': text});
  }

  void sendSignal(Map<String, dynamic> m) => _send(m);

  Future<void> addCall(CallRecord r) async {
    calls.insert(0, r);
    if (calls.length > 100) calls = calls.sublist(0, 100);
    await _prefs.setString('calls', jsonEncode(calls.map((c) => c.toJson()).toList()));
    notifyListeners();
  }
}
