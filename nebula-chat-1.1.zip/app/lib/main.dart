import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app_state.dart';
import 'call_service.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'helper/helper_overlay.dart';
import 'helper/helper_service.dart';
import 'theme.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: NebulaColors.bgDeep,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  await AppState.I.init();
  await HelperService.I.init();
  await CallService.I.init(navigatorKey);
  runApp(const NebulaApp());
}

class NebulaApp extends StatelessWidget {
  const NebulaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nebula Chat',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      navigatorKey: navigatorKey,
      builder: (context, child) => HelperOverlay(child: child ?? const SizedBox()),
      home: ValueListenableBuilder<bool>(
        valueListenable: AppState.I.loggedIn,
        builder: (context, ok, _) => AnimatedSwitcher(
          duration: const Duration(milliseconds: 450),
          switchInCurve: Curves.easeOutCubic,
          child: ok
              ? const HomeScreen(key: ValueKey('home'))
              : const AuthScreen(key: ValueKey('auth')),
        ),
      ),
    );
  }
}
