import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'helper_models.dart';

/// Настройки помощников (звёздочка и пузырёк), хранятся на устройстве.
class HelperService extends ChangeNotifier {
  HelperService._();
  static final HelperService I = HelperService._();

  bool starOn = true;
  bool bubbleOn = true;
  String starModel = 'classic';
  String bubbleModel = 'soap';
  SharedPreferences? _p;

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    starOn = _p!.getBool('h_star_on') ?? true;
    bubbleOn = _p!.getBool('h_bub_on') ?? true;
    final s = _p!.getString('h_star') ?? 'classic';
    final b = _p!.getString('h_bub') ?? 'soap';
    if (kHelperModels.any((m) => m.id == s && !m.bubble)) starModel = s;
    if (kHelperModels.any((m) => m.id == b && m.bubble)) bubbleModel = b;
  }

  void setStarOn(bool v) {
    starOn = v;
    _p?.setBool('h_star_on', v);
    notifyListeners();
  }

  void setBubbleOn(bool v) {
    bubbleOn = v;
    _p?.setBool('h_bub_on', v);
    notifyListeners();
  }

  void setModel(HelperModel m) {
    if (m.bubble) {
      bubbleModel = m.id;
      _p?.setString('h_bub', m.id);
    } else {
      starModel = m.id;
      _p?.setString('h_star', m.id);
    }
    notifyListeners();
  }
}
