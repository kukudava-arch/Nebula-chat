'use strict';
/**
 * Nebula Chat - тестовый сервер.
 *  - HTTP:  POST /api/register, POST /api/login, GET /health
 *  - WS:    /ws?token=...  (сообщения, поиск, история, сигналинг звонков WebRTC)
 *  - Данные хранятся в одном JSON-файле (для теста; для продакшена нужна БД).
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const PORT = Number(process.env.PORT) || 3000;
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data.json');

// ---------- хранилище ----------
let db = { users: {}, tokens: {}, convs: {} };

try {
  if (fs.existsSync(DATA_FILE)) {
    db = Object.assign(db, JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')));
  }
} catch (e) {
  console.error('Не удалось прочитать data.json, стартуем с пустой базой:', e.message);
}

let saveTimer = null;
function saveSoon() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      const tmp = DATA_FILE + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(db));
      fs.renameSync(tmp, DATA_FILE);
    } catch (e) {
      console.error('Ошибка сохранения:', e.message);
    }
  }, 500);
}
function saveNow() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(db));
  } catch (e) {
    console.error('Ошибка сохранения:', e.message);
  }
}

// ---------- утилиты ----------
const USERNAME_RE = /^[a-z0-9_]{3,20}$/;

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function safeEqualHex(a, b) {
  const ba = Buffer.from(a, 'hex');
  const bb = Buffer.from(b, 'hex');
  return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
}

function newToken(username) {
  const token = crypto.randomBytes(32).toString('hex');
  db.tokens[token] = username;
  saveSoon();
  return token;
}

function convKey(a, b) {
  return [a, b].sort().join('|');
}

function publicUser(username) {
  const u = db.users[username];
  return u ? { username, displayName: u.displayName } : null;
}

// простой лимитер по ключу: не более `max` событий за `windowMs`
const buckets = new Map();
function rateLimited(key, max, windowMs) {
  const now = Date.now();
  const arr = (buckets.get(key) || []).filter((t) => now - t < windowMs);
  if (arr.length >= max) {
    buckets.set(key, arr);
    return true;
  }
  arr.push(now);
  buckets.set(key, arr);
  return false;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, arr] of buckets) {
    const fresh = arr.filter((t) => now - t < 120000);
    if (fresh.length) buckets.set(k, fresh);
    else buckets.delete(k);
  }
}, 60000).unref();

// ---------- HTTP ----------
function readJson(req, limit = 10 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(new Error('too_large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch (e) {
        reject(new Error('bad_json'));
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  const ip = req.socket.remoteAddress || 'unknown';
  try {
    if (req.method === 'GET' && req.url === '/health') {
      return sendJson(res, 200, { ok: true });
    }

    if (req.method === 'POST' && (req.url === '/api/register' || req.url === '/api/login')) {
      if (rateLimited('auth:' + ip, 20, 60 * 1000)) {
        return sendJson(res, 429, { error: 'Слишком много попыток, подождите минуту' });
      }
      const body = await readJson(req);
      const username = String(body.username || '').trim().toLowerCase();
      const password = String(body.password || '');

      if (req.url === '/api/register') {
        const displayName = String(body.displayName || '').trim().slice(0, 40) || username;
        if (!USERNAME_RE.test(username)) {
          return sendJson(res, 400, {
            error: 'Логин: 3–20 символов, только латиница, цифры и _',
          });
        }
        if (password.length < 6 || password.length > 100) {
          return sendJson(res, 400, { error: 'Пароль: от 6 до 100 символов' });
        }
        if (db.users[username]) {
          return sendJson(res, 409, { error: 'Такой логин уже занят' });
        }
        const salt = crypto.randomBytes(16).toString('hex');
        db.users[username] = {
          displayName,
          salt,
          hash: hashPassword(password, salt),
          createdAt: Date.now(),
        };
        const token = newToken(username);
        return sendJson(res, 200, { token, username, displayName });
      }

      // login
      const user = db.users[username];
      if (!user || !safeEqualHex(user.hash, hashPassword(password, user.salt))) {
        return sendJson(res, 401, { error: 'Неверный логин или пароль' });
      }
      const token = newToken(username);
      return sendJson(res, 200, { token, username, displayName: user.displayName });
    }

    sendJson(res, 404, { error: 'not_found' });
  } catch (e) {
    if (e.message === 'too_large') return sendJson(res, 413, { error: 'Слишком большой запрос' });
    if (e.message === 'bad_json') return sendJson(res, 400, { error: 'Некорректный запрос' });
    console.error(e);
    sendJson(res, 500, { error: 'Ошибка сервера' });
  }
});

// ---------- WebSocket ----------
const wss = new WebSocketServer({ noServer: true, maxPayload: 256 * 1024 });
const online = new Map(); // username -> Set<ws>

server.on('upgrade', (req, socket, head) => {
  let token = '';
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname !== '/ws') throw new Error('bad_path');
    token = url.searchParams.get('token') || '';
  } catch (e) {
    socket.destroy();
    return;
  }
  const username = db.tokens[token];
  if (!username || !db.users[username]) {
    socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
    socket.destroy();
    return;
  }
  wss.handleUpgrade(req, socket, head, (ws) => {
    ws.username = username;
    wss.emit('connection', ws, req);
  });
});

function sendTo(username, obj) {
  const set = online.get(username);
  if (!set) return false;
  const data = JSON.stringify(obj);
  let delivered = false;
  for (const ws of set) {
    if (ws.readyState === ws.OPEN) {
      ws.send(data);
      delivered = true;
    }
  }
  return delivered;
}

function reply(ws, obj) {
  if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(obj));
}

function buildChats(username) {
  const out = [];
  for (const [key, msgs] of Object.entries(db.convs)) {
    const [a, b] = key.split('|');
    if (a !== username && b !== username) continue;
    if (!msgs.length) continue;
    const other = a === username ? b : a;
    const last = msgs[msgs.length - 1];
    const u = publicUser(other);
    if (!u) continue;
    out.push({
      user: other,
      displayName: u.displayName,
      text: last.text,
      ts: last.ts,
      from: last.from,
    });
  }
  out.sort((x, y) => y.ts - x.ts);
  return out;
}

const SIGNAL_TYPES = new Set(['call_offer', 'call_answer', 'call_ice', 'call_end', 'call_reject']);

wss.on('connection', (ws) => {
  const me = ws.username;
  if (!online.has(me)) online.set(me, new Set());
  online.get(me).add(ws);
  ws.isAlive = true;
  ws.on('pong', () => (ws.isAlive = true));

  reply(ws, { type: 'hello', username: me, displayName: db.users[me].displayName });

  ws.on('message', (raw) => {
    let m;
    try {
      m = JSON.parse(raw.toString());
    } catch (e) {
      return;
    }
    if (!m || typeof m.type !== 'string') return;

    switch (m.type) {
      case 'chats':
        reply(ws, { type: 'chats', chats: buildChats(me) });
        break;

      case 'history': {
        const other = String(m.with || '').toLowerCase();
        const msgs = db.convs[convKey(me, other)] || [];
        reply(ws, { type: 'history', with: other, messages: msgs.slice(-200) });
        break;
      }

      case 'search': {
        const q = String(m.q || '').trim().toLowerCase().slice(0, 30);
        if (q.length < 2) {
          reply(ws, { type: 'search', users: [] });
          break;
        }
        const users = [];
        for (const [uname, u] of Object.entries(db.users)) {
          if (uname === me) continue;
          if (uname.includes(q) || u.displayName.toLowerCase().includes(q)) {
            users.push({ username: uname, displayName: u.displayName });
            if (users.length >= 20) break;
          }
        }
        reply(ws, { type: 'search', users });
        break;
      }

      case 'send': {
        if (rateLimited('msg:' + me, 40, 10 * 1000)) {
          reply(ws, { type: 'error', error: 'Слишком быстро. Подождите немного.' });
          break;
        }
        const to = String(m.to || '').toLowerCase();
        const text = String(m.text || '').trim().slice(0, 4000);
        if (!text || !db.users[to] || to === me) break;
        const msg = {
          id: crypto.randomUUID(),
          from: me,
          to,
          text,
          ts: Date.now(),
        };
        const key = convKey(me, to);
        (db.convs[key] = db.convs[key] || []).push(msg);
        saveSoon();
        sendTo(me, { type: 'message', msg, fromName: db.users[me].displayName });
        sendTo(to, { type: 'message', msg, fromName: db.users[me].displayName });
        break;
      }

      default: {
        if (!SIGNAL_TYPES.has(m.type)) break;
        const to = String(m.to || '').toLowerCase();
        if (!db.users[to] || to === me) break;
        // ограничим размер полезной нагрузки сигналов
        if (JSON.stringify(m).length > 60 * 1024) break;
        const payload = Object.assign({}, m, {
          from: me,
          fromName: db.users[me].displayName,
          to,
        });
        const delivered = sendTo(to, payload);
        if (!delivered && m.type === 'call_offer') {
          reply(ws, { type: 'call_unavailable', from: to });
        }
        break;
      }
    }
  });

  ws.on('close', () => {
    const set = online.get(me);
    if (set) {
      set.delete(ws);
      if (!set.size) online.delete(me);
    }
  });
  ws.on('error', () => {});
});

// отсекаем «мёртвые» соединения
const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (ws.isAlive === false) {
      ws.terminate();
      continue;
    }
    ws.isAlive = false;
    try {
      ws.ping();
    } catch (e) {
      /* ignore */
    }
  }
}, 30000);
heartbeat.unref();

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Nebula Chat server запущен на порту ${PORT}`);
});

function shutdown() {
  saveNow();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
