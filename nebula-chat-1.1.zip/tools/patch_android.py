#!/usr/bin/env python3
"""Донастраивает Android-проект, созданный командой `flutter create`:
разрешения (интернет, микрофон, камера), доступ по http к тестовому серверу,
название приложения и минимальная версия Android для WebRTC.
Запускать из папки app/."""
import pathlib
import re
import sys

ROOT = pathlib.Path("android")
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"

PERMISSIONS = """
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.CHANGE_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.CAMERA"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
    <uses-feature android:name="android.hardware.camera" android:required="false"/>
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false"/>
"""


def patch_manifest() -> None:
    text = MANIFEST.read_text(encoding="utf-8")

    if "android.permission.RECORD_AUDIO" not in text:
        text, n = re.subn(r"(<manifest[^>]*>)", lambda m: m.group(1) + PERMISSIONS, text, count=1)
        if n != 1:
            sys.exit("Не нашёл тег <manifest> в AndroidManifest.xml")

    if "usesCleartextTraffic" not in text:
        text, n = re.subn(
            r"<application",
            '<application\n        android:usesCleartextTraffic="true"',
            text,
            count=1,
        )
        if n != 1:
            sys.exit("Не нашёл тег <application> в AndroidManifest.xml")

    text = re.sub(r'android:label="[^"]*"', 'android:label="Nebula Chat"', text, count=1)
    MANIFEST.write_text(text, encoding="utf-8")
    print("AndroidManifest.xml: OK")


def patch_min_sdk() -> None:
    for name in ("app/build.gradle.kts", "app/build.gradle"):
        path = ROOT / name
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        new = re.sub(r"minSdk\s*=\s*flutter\.minSdkVersion", "minSdk = 24", text)
        new = re.sub(r"minSdkVersion\s+flutter\.minSdkVersion", "minSdkVersion 24", new)
        if new != text:
            path.write_text(new, encoding="utf-8")
            print(f"{name}: minSdk = 24")
        else:
            print(f"{name}: minSdk не менялся (уже задан)")
        return
    print("build.gradle не найден — minSdk не менялся")


if __name__ == "__main__":
    if not MANIFEST.exists():
        sys.exit("Запускайте из папки app/ после `flutter create`")
    patch_manifest()
    patch_min_sdk()
